# ds1832 — iPhone 13 Pro Max / iOS 18.3.2 内核原语层

`iPhone14,3` · A15 · iOS 18.3.2 · arm64e

---

## 0. 你这台机器的处境

| 项目 | 状态 |
|---|---|
| 芯片 | A15 Bionic，**没有 MTE**（M5/A19 才有），所以 18.3.2 这条链对你是开的 |
| 页表保护 | **PPL**（A12–A15），不是 A16+ 的 SPTM —— 也就是说硬壳还在，但不是最狠的那层 |
| 内核 r/w | 可达，走 CVE-2025-43520 |
| 完整越狱（tweak 注入 / 未签名 kext） | 不可达，KTRR/PPL 挡着代码段 |
| 能拿到的实际战果 | 全盘读写、MobileGestalt、JIT、App 解密、OTA 屏蔽这一类 |

参考实现：[ClearSword](https://therealclarity.github.io/blog/clearsword/)（C 重写，测到 26.0.1）、[lara](https://github.com/rooootdev/lara)（打包成 App，支持 17.0–18.7.1）。

这个项目**不是**上面两个的拷贝，是从零写的一条流水线，目标是把中间每一层可验证化：每个阶段都往磁盘写日志，因为 panic 会把进程直接抹掉。

---

## 1. 漏洞

`CVE-2025-43520`，VFS 竞态，位置在 `cluster_write_contig` / `cluster_read_contig`：

- `cluster_io_type()` 查一次 `UPL_PHYS_CONTIG`，据此选"物理连续直拷"策略
- `cluster_write_contig()` 自己又调一次 `vm_map_get_upl()`，但**不再看返回的 flags**
- 在这两次之间把同一段 VA 的映射换成物理不连续的，内核仍按 `paddr0 + n*0x4000` 寻址
- 于是 iov 尾巴落到"第一页之后的那个物理页"——通常是别人的页

补丁就是把 flags 校验插到第二次 `vm_map_get_upl` 之后。

两个方向的语义（按 fd 视角命名，很容易搞反）：

```
pwrite()  memory -> file   == 物理读，读到相邻物理页
pread()   file   -> memory == 物理写，写到相邻物理页
```

数据布局（`devblocksize = 0x1000`，vm page = `0x4000`）：

```
iov_base = region + 0x3f00 , iov_len = 0x1000 , file offset = 0x3f00
  ├─ head 0x100  → 落在我们自己的 page0（无害）
  └─ tail 0xf00  → 落在 page0 之后的物理页（越界窗口）
```

post-loop 的对齐检查让函数返回 `EINVAL` —— 这就是"进到 contig 分支了"的信号，但**成功与否只能看内容**，errno 分辨不了。这个项目里两个信号都记。

---

## 2. 这个仓库里有什么

```
ds1832.xcodeproj    开箱即用的 App 工程（arm64 / iOS 15.0 / 已链接 IOSurface）
build.sh            命令行出未签名 ipa（AltStore/SideStore 重签用）
.github/workflows   macOS runner 上跑同一个脚本，artifact 直接下载
src/ds_log.c       单实例日志：所有 TU 追加到同一个文件，写一行 fsync 一次
src/ds_race.c      竞态本体：PurpleGfxMem 连续映射、双映射切换、两个方向的读写
src/ds_oracle.c    socket 喷射 + gencnt 标定 + 标记化 arena
src/ds_exploit.c   编排：初始化 → 标定 → arena → 喷射 → 竞态 → 证明
app/main.m         UIKit 外壳，跑在后台线程，实时刷日志
```

### 已经做到"自证"的两件事

**gencnt 偏移不用硬编码。**
`socket_fdinfo` 里 `insi_gencnt` 的位置会随版本漂。这里不写死，启动时连开三个新 socket，取回 blob，找那种"三个都不同、且按创建顺序递增 1"的 qword —— 那就是 gencnt。找不到就直接判失败，不会带病往下跑。

**写原语不靠猜。**
arena 里每个 16KB 页开头都种了唯一标记（`0x44534d4b` + 页号）。一旦越界窗口里出现我们自己 arena 页的标记，就说明"相邻物理页是我自己的页"—— 这时候才写，写完直接从用户态读那个页比对。对得上才算 `window_written = 1`。没有拿内核内存做实验。

### 还没做的（Part 2）

- 拿到 inpcb 之后把它转成任意内核虚拟读写（`so_pcb` 重定向那套）
- `kernproc` / 本进程 `proc` / `ucred` 的运行时定位（扫 proc 链表比对 pid 与 comm，不硬编码偏移）
- 页表遍历做 kv→phys（`t1sz_boot`、`gVirtBase` 从活内存里找，不从文件里读）
- 战果层：全盘读写、MobileGestalt 编辑器、OTA 屏蔽、App 解密

---

## 3. 构建

### 3.1 直接开 Xcode 工程（推荐）

`ds1832.xcodeproj` 已经在仓库根目录，所有源文件、framework、编译设置都配好了，双击就能开：

- target `ds1832`，Deployment Target **iOS 15.0**
- `ARCHS = arm64`（App 走普通 arm64，别设 arm64e，侧载签名会失败）
- ARC 开、`CLANG_ENABLE_MODULES = YES`
- 已链接：`UIKit` / `Foundation` / `IOSurface` / `CoreGraphics` / `CoreFoundation`
- `HEADER_SEARCH_PATHS = $(SRCROOT)/src`
- `INFOPLIST_FILE = app/Info.plist`，`CODE_SIGN_ENTITLEMENTS = entitlements.plist`

真机运行前只改一处：**Signing & Capabilities → Team 选你的开发者账号**（`DEVELOPMENT_TEAM` 现在是空的），Bundle ID 想改就改 `PRODUCT_BUNDLE_IDENTIFIER`。

> `entitlements.plist` 里只留了 `com.apple.security.get-task-allow`。这东西是给你连 LLDB 看 panic 前最后一步用的，别塞进 App Store 提交。

### 3.2 命令行 / 没有 Mac

`build.sh` 出**未签名 ipa**，用 AltStore / SideStore 装的时候它会用自己的证书重签：

```sh
./build.sh                  # -> ds1832.ipa
CONF=Debug ./build.sh       # 带 -O0 的调试版
```

没有 Mac 也行：`.github/workflows/build.yml` 会在 `macos-14` runner 上跑同一个脚本，把 `ds1832.ipa` 作为 artifact 传上来。推仓库 → Actions → 下载 artifact → AltServer 装上。

### 3.3 Theos（可选，出 deb）

```sh
export THEOS=~/theos
make clean package          # packages/com.kv.ds1832_0.1_iphoneos-arm64.deb
```

**签名注意**：A12+ 不越狱的设备只能装签名 App。TrollStore 在 18.x 上没戏（CoreTrust 洞止于 17.0.1），所以走 AltStore/SideStore + 你自己的证书。免费证书每 7 天要重签一次。

---

## 4. 跑起来会看到什么

点 `run primitive chain`，然后看状态栏四行：

```
stage: racing
attempts: 128340  contig: 41  socks: 2048
marker page: -1  socket: -1 @0x0
write confirmed: 0
```

- `attempts` 涨得快、`contig` 涨得慢是正常的：`EINVAL` 只在真的进了 contig 分支才出现，命中率通常千分之一量级
- `marker page` 出现数字 = **相邻物理页是我们自己的 arena 页**，接着 `write confirmed` 应该变 1，这是原语成功的铁证
- `socket: N @0x...` = 窗口里撞到了第 N 个 socket 的 inpcb，位置在窗口内 `0x...` 偏移。这条是 Part 2 的入口
- 一直 `-1` 到 40 轮耗尽 = 需要在下面几个地方调

### 调参位

| 想改什么 | 改哪里 |
|---|---|
| arena 大小（越大命中越高，越吃内存） | `DS_ARENA_CHUNK` / `DS_ARENA_CHUNKS`（`ds_oracle.h`），默认 8×64MiB；ClearSword 用 8×128MiB |
| socket 数量 | `DS_MAX_SOCKS`，默认 2048 |
| 竞态预算 | `ds_exploit.c` 里 `round_budget` / `rounds` |
| 连续映射拿不到 | `ds_race.c` 的 `ds_map_contig_ioregion()`：先试 `IOSurfaceGetBaseAddress`，失败退 `mach_vm_remap`，再退 `mach_make_memory_entry_64` |

如果日志第一行就是 `contig: PurpleGfxMem surface is not CPU mappable` —— 这台设备/这个 build 上 IOSurface 不给 CPU 直映射，得换连续页来源（`IOSurface` + `IOSurfaceLock` 路线，或者 GPU 侧 `IOCommandBuffer`）。

---

## 5. 上机前的实话

- **会 panic**。竞态打在 VFS 上，窗口没夹准就是内核崩，轻则重启重则丢未同步数据。**先 iTunes/Finder 备份**，别在有价值的手机上第一次跑。
- 第一次跑建议把 `round_budget` 调到 2000 左右，看 `contig` 能不能涨，再放开。
- 崩溃日志在 `/var/mobile/Library/Logs/CrashReporter/panic-full-*.ips`，用 [ipsw](https://github.com/blacktop/ipsw) 符号化（`ipsw symbolicate panic`），能直接看出是死在 `cluster_write_contig` 还是别处。
- App 从后台划掉时内核可能还挂在 UPL 上 —— `dis_race_stop()` 已经在退出路径上了，但物理内存压力大时不保证。

---

## 6. 下一步

Part 2 我会接着写：inpcb → 任意内核虚拟读写 → proc/ucred 运行时定位 → 战果层。

要不要先跑一次，把 `ds-run.log` 贴回来？前 20 行就够我判断这条链在你这台机器上的实际命中率，然后再决定 Part 2 是按 inpcb 路线还是换 socket 对象路线。
