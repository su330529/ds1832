#!/bin/bash
# build.sh — unsigned build + .ipa packaging for AltStore / SideStore re-signing.
# run on macOS or in the GitHub Actions workflow (.github/workflows/build.yml).
set -euo pipefail
cd "$(dirname "$0")"

SCHEME=ds1832
CONF=${CONF:-Release}
DERIVED=${DERIVED:-build}

echo "== build ($CONF, unsigned) =="
xcodebuild \
  -project ds1832.xcodeproj \
  -scheme "$SCHEME" \
  -configuration "$CONF" \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$DERIVED" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  CODE_SIGN_ENTITLEMENTS="" \
  build

APP="$DERIVED/Build/Products/$CONF-iphoneos/ds1832.app"
[ -d "$APP" ] || { echo "no app bundle at $APP"; exit 1; }

echo "== package =="
rm -rf Payload ds1832.ipa
mkdir -p Payload
cp -R "$APP" Payload/
zip -qry ds1832.ipa Payload
rm -rf Payload
echo "-> $(pwd)/ds1832.ipa  ($(du -h ds1832.ipa | cut -f1))"
