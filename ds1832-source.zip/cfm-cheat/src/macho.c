// macho.c — in-memory Mach-O: load commands, segments, export trie
#include "macho.h"
#include <string.h>
#include <stdlib.h>

#define MH_MAGIC_64   0xfeedfacfu
#define MH_CIGAM_64   0xcffaedfeu
#define LC_SEGMENT_64 0x19u
#define LC_SYMTAB     0x2u
#define LC_DYLD_INFO  0x22u
#define LC_DYLD_INFO_ONLY 0x80000022u
#define LC_DYLD_EXPORTS_TRIE 0x80000033u

static int rd(macho_t *m, uint64_t va, void *buf, size_t len) {
    return m->read(m->ctx, va, buf, len);
}

int macho_parse(mread_fn fn, void *ctx, uint64_t base, macho_t *m) {
    memset(m, 0, sizeof(*m));
    m->read = fn;
    m->ctx = ctx;
    m->base = base;

    uint32_t hdr[8];
    if (rd(m, base, hdr, sizeof(hdr)) != 0)
        return -1;
    if (hdr[0] != MH_MAGIC_64 && hdr[0] != MH_CIGAM_64)
        return -2;

    m->magic = hdr[0];
    m->cputype = hdr[1];
    m->cpusubtype = hdr[2];
    m->filetype = hdr[3];
    m->ncmds = hdr[4];
    m->sizeofcmds = hdr[5];

    uint64_t cmd_va = base + 32;
    for (uint32_t i = 0; i < m->ncmds; i++) {
        uint32_t head[2];
        if (rd(m, cmd_va, head, 8) != 0)
            return -3;
        uint32_t cmd = head[0], cmdsize = head[1];
        if (cmdsize < 8 || cmdsize > (1u << 20))
            return -4;

        if (cmd == LC_SEGMENT_64) {
            uint8_t buf[72];
            if (rd(m, cmd_va, buf, sizeof(buf)) != 0)
                return -5;
            if (m->nsegs < MACHO_MAX_SEGS) {
                macho_seg *s = &m->segs[m->nsegs];
                memcpy(s->seg, buf + 8, 16);
                s->seg[16] = 0;
                memcpy(&s->vmaddr, buf + 24, 8);
                memcpy(&s->vmsize, buf + 32, 8);
                memcpy(&s->fileoff, buf + 40, 8);
                memcpy(&s->filesize, buf + 48, 8);
                m->nsegs++;
            }
            // walk sections to find e.g. __TEXT,__cstring later
            uint32_t nsects;
            memcpy(&nsects, buf + 64, 4);
            for (uint32_t s = 0; s < nsects && m->nsects < MACHO_MAX_SECTS; s++) {
                uint8_t sb[80];
                uint64_t sva = cmd_va + 72 + (uint64_t)s * 80;
                if (rd(m, sva, sb, sizeof(sb)) != 0)
                    break;
                macho_sect *sec = &m->sects[m->nsects];
                memcpy(sec->sect, sb, 16);
                sec->sect[16] = 0;
                memcpy(sec->seg, sb + 16, 16);
                sec->seg[16] = 0;
                memcpy(&sec->addr, sb + 32, 8);
                memcpy(&sec->size, sb + 40, 8);
                memcpy(&sec->offset, sb + 48, 4);
                m->nsects++;
            }
        } else if (cmd == LC_SYMTAB) {
            uint8_t buf[24];
            if (rd(m, cmd_va, buf, sizeof(buf)) == 0) {
                memcpy(&m->symoff, buf + 8, 4);
                memcpy(&m->nsyms, buf + 12, 4);
                memcpy(&m->stroff, buf + 16, 4);
                memcpy(&m->strsize, buf + 20, 4);
            }
        } else if (cmd == LC_DYLD_EXPORTS_TRIE) {
            uint8_t buf[16];
            if (rd(m, cmd_va, buf, sizeof(buf)) == 0) {
                uint32_t off = 0, sz = 0;
                memcpy(&off, buf + 8, 4);
                memcpy(&sz, buf + 12, 4);
                m->exports_va = base + off;
                m->exports_size = sz;
            }
        } else if (cmd == LC_DYLD_INFO || cmd == LC_DYLD_INFO_ONLY) {
            uint8_t buf[48];
            if (rd(m, cmd_va, buf, sizeof(buf)) == 0 && !m->exports_va) {
                uint32_t off = 0, sz = 0;
                memcpy(&off, buf + 40, 4);   // export_off
                memcpy(&sz, buf + 44, 4);    // export_size
                if (off && sz) {
                    m->exports_va = base + off;
                    m->exports_size = sz;
                }
            }
        }
        cmd_va += cmdsize;
    }
    return 0;
}

int macho_find_segment(const macho_t *m, const char *name, uint64_t *vmaddr, uint64_t *vmsize) {
    for (int i = 0; i < m->nsegs; i++) {
        if (!strncmp(m->segs[i].seg, name, 16)) {
            if (vmaddr) *vmaddr = m->segs[i].vmaddr;
            if (vmsize) *vmsize = m->segs[i].vmsize;
            return 0;
        }
    }
    return -1;
}

uint64_t macho_seg_va(const macho_t *m, const char *name) {
    uint64_t vmaddr = 0;
    if (macho_find_segment(m, name, &vmaddr, NULL) != 0)
        return 0;
    // vmaddr is the unslid address; the image is mapped at m->base for __TEXT
    return m->base + (vmaddr - m->segs[0].vmaddr);
}

int macho_find_section(const macho_t *m, const char *seg, const char *sect,
                       uint64_t *addr, uint64_t *size) {
    for (int i = 0; i < m->nsects; i++) {
        if (!strncmp(m->sects[i].seg, seg, 16) && !strncmp(m->sects[i].sect, sect, 16)) {
            uint64_t slide = m->base - m->segs[0].vmaddr;
            if (addr) *addr = m->sects[i].addr + slide;
            if (size) *size = m->sects[i].size;
            return 0;
        }
    }
    return -1;
}

// ---- export trie ----------------------------------------------------------
// node := terminal_size uleb, [flags uleb, (reexport: ordinal uleb + cstr) |
//          address uleb], child_count u8, { edge_cstr, child_offset uleb }*
typedef struct {
    const uint8_t *p;
    size_t len;
} ubuf;

static uint64_t uleb(ubuf *b, size_t *pos) {
    uint64_t v = 0;
    int shift = 0;
    while (*pos < b->len) {
        uint8_t c = b->p[(*pos)++];
        v |= (uint64_t)(c & 0x7f) << shift;
        if (!(c & 0x80))
            break;
        shift += 7;
        if (shift > 63) break;
    }
    return v;
}

static int trie_walk(ubuf *b, size_t node, const char *want, size_t wpos,
                     uint64_t *out_addr, int depth) {
    if (depth > 64 || node >= b->len)
        return 0;
    size_t pos = node;
    uint64_t tsize = uleb(b, &pos);
    size_t term_end = pos + (size_t)tsize;

    if (tsize) {
        if (want[wpos] == 0) {
            size_t t = pos;
            uleb(b, &t);                 // flags
            // reexports carry no address; treat as not found
            uint64_t addr = uleb(b, &t);
            if (addr) {
                *out_addr = addr;
                return 1;
            }
        }
    }
    if (pos > term_end) pos = term_end;
    if (term_end >= b->len) return 0;

    uint8_t child_count = b->p[term_end];
    size_t cp = term_end + 1;
    for (uint8_t i = 0; i < child_count; i++) {
        size_t s = cp;
        while (s < b->len && b->p[s]) s++;
        if (s >= b->len) return 0;
        size_t elen = s - cp;
        uint64_t child = uleb(b, &s);
        if (strncmp((const char *)b->p + cp, want + wpos, elen) == 0) {
            if (trie_walk(b, (size_t)child, want, wpos + elen, out_addr, depth + 1))
                return 1;
        }
        cp = s;
    }
    return 0;
}

uint64_t macho_lookup_export(const macho_t *m, const char *name) {
    if (!m->exports_va || !m->exports_size || m->exports_size > (8u << 20))
        return 0;
    uint8_t *buf = malloc((size_t)m->exports_size);
    if (!buf) return 0;
    if (m->read(m->ctx, m->exports_va, buf, (size_t)m->exports_size) != 0) {
        free(buf);
        return 0;
    }
    ubuf b = { buf, (size_t)m->exports_size };
    uint64_t off = 0;
    uint64_t result = 0;
    if (trie_walk(&b, 0, name, 0, &off, 0))
        result = m->base + off;      // export offsets are image-relative
    free(buf);
    return result;
}
