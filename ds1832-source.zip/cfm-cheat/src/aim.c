// aim.c — see aim.h
#include "aim.h"
#include "kwr.h"
#include "cfm_offsets.h"
#include <math.h>
#include <string.h>

static float angular_distance(const aim_angles *cur, vec3 eye, vec3 point) {
    float tp, ty;
    dir_to_angles(v3_sub(point, eye), &tp, &ty);
    float dp = angle_delta(cur->pitch, tp);
    float dy = angle_delta(cur->yaw, ty);
    return sqrtf(dp * dp + dy * dy);
}

int aim_pick(const aim_config *cfg, const aim_angles *current,
             const aim_target *targets, int n, vec3 eye, int *chosen) {
    int best = -1;
    float best_score = 1e9f;

    for (int i = 0; i < n; i++) {
        const aim_target *t = &targets[i];
        if (!t->alive) continue;
        if (cfg->require_visible && !t->visible) continue;
        if (t->distance > 0 && t->distance > cfg->max_distance) continue;

        float ang = angular_distance(current, eye, t->head);
        if (ang > cfg->fov_deg) continue;

        // prefer what is closer to the crosshair, break ties by distance
        float score = ang * 100.0f + t->distance;
        if (score < best_score) {
            best_score = score;
            best = i;
        }
    }
    if (best >= 0 && chosen) *chosen = best;
    return best;
}

int aim_compute(const aim_config *cfg, const aim_angles *current,
                const aim_target *target, vec3 eye, aim_angles *out) {
    if (!target) return -1;
    vec3 aim_point = target->head;
    float tp, ty;
    dir_to_angles(v3_sub(aim_point, eye), &tp, &ty);

    float s = clampf(cfg->smooth, 0.01f, 1.0f);
    out->pitch = smooth_step(current->pitch, tp, s);
    out->yaw   = smooth_step(current->yaw, ty, s);
    return 0;
}

int aim_apply(pid_t pid, uint64_t angles_field, const aim_angles *a) {
    if (!angles_field) return -1;
    // Unity stores euler angles as three contiguous floats
    if (kwr_uwrite_f32(pid, angles_field + CFM_OFF_ANGLE_PITCH, a->pitch) != 0)
        return -2;
    if (kwr_uwrite_f32(pid, angles_field + CFM_OFF_ANGLE_YAW, a->yaw) != 0)
        return -3;
    if (CFM_WRITE_ROLL)
        kwr_uwrite_f32(pid, angles_field + CFM_OFF_ANGLE_ROLL, 0.0f);
    return 0;
}
