// macho.h — parse a Mach-O that lives in another process's memory
#ifndef MACHO_H
#define MACHO_H

#include <stdint.h>
#include <stddef.h>

typedef int (*mread_fn)(void *ctx, uint64_t va, void *buf, size_t len);

#define MACHO_MAX_SEGS 32
#define MACHO_MAX_SECTS 128

typedef struct {
    char     seg[17];
    uint64_t vmaddr, vmsize;
    uint64_t fileoff, filesize;
} macho_seg;

typedef struct {
    char     seg[17];
    char     sect[17];
    uint64_t addr, size, offset;
} macho_sect;

typedef struct {
    mread_fn read;
    void    *ctx;
    uint64_t base;            // VM address of the mach header
    uint32_t magic, cputype, cpusubtype, filetype, ncmds, sizeofcmds;

    int         nsegs;
    macho_seg   segs[MACHO_MAX_SEGS];
    int         nsects;
    macho_sect  sects[MACHO_MAX_SECTS];

    uint64_t exports_va, exports_size;     // LC_DYLD_EXPORTS_TRIE / LC_DYLD_INFO
    uint64_t symoff, nsyms, stroff, strsize;
} macho_t;

int      macho_parse(mread_fn rd, void *ctx, uint64_t base, macho_t *m);
int      macho_find_segment(const macho_t *m, const char *name, uint64_t *vmaddr, uint64_t *vmsize);
int      macho_find_section(const macho_t *m, const char *seg, const char *sect,
                            uint64_t *addr, uint64_t *size);
uint64_t macho_lookup_export(const macho_t *m, const char *name);
// finds where the given segment's bytes live, walking down from base
uint64_t macho_seg_va(const macho_t *m, const char *name);

#endif
