// math3d.h — vectors, projection, aim angles (Unity conventions, degrees)
#ifndef MATH3D_H
#define MATH3D_H

#include <math.h>
#include <stdint.h>

typedef struct { float x, y, z; } vec3;
typedef struct { float x, y; } vec2;

// Unity matrices are column-major: m[col * 4 + row]
typedef struct { float m[16]; } mat4;

static inline vec3 v3(float x, float y, float z) { vec3 v = {x, y, z}; return v; }
static inline vec3 v3_add(vec3 a, vec3 b) { return v3(a.x + b.x, a.y + b.y, a.z + b.z); }
static inline vec3 v3_sub(vec3 a, vec3 b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static inline vec3 v3_mul(vec3 a, float s) { return v3(a.x * s, a.y * s, a.z * s); }
static inline float v3_dot(vec3 a, vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline float v3_len(vec3 a) { return sqrtf(v3_dot(a, a)); }
static inline float v3_dist(vec3 a, vec3 b) { return v3_len(v3_sub(a, b)); }

static inline vec3 v3_norm(vec3 a) {
    float l = v3_len(a);
    return l > 1e-6f ? v3_mul(a, 1.0f / l) : v3(0, 0, 0);
}

static inline vec3 mat4_mul_point(const mat4 *m, vec3 p) {
    // clip = M * (p, 1)
    float x = m->m[0] * p.x + m->m[4] * p.y + m->m[8]  * p.z + m->m[12];
    float y = m->m[1] * p.x + m->m[5] * p.y + m->m[9]  * p.z + m->m[13];
    float z = m->m[2] * p.x + m->m[6] * p.y + m->m[10] * p.z + m->m[14];
    float w = m->m[3] * p.x + m->m[7] * p.y + m->m[11] * p.z + m->m[15];
    if (fabsf(w) < 1e-6f) w = 1e-6f;
    return v3(x / w, y / w, z / w);
}

// view-projection (Unity: projection * worldToCamera) -> screen pixels.
// returns 0 when the point is behind the camera.
static inline int world_to_screen(const mat4 *vp, vec3 world, float sw, float sh,
                                  vec2 *out, float *depth) {
    float x = vp->m[0] * world.x + vp->m[4] * world.y + vp->m[8]  * world.z + vp->m[12];
    float y = vp->m[1] * world.x + vp->m[5] * world.y + vp->m[9]  * world.z + vp->m[13];
    float z = vp->m[2] * world.x + vp->m[6] * world.y + vp->m[10] * world.z + vp->m[14];
    float w = vp->m[3] * world.x + vp->m[7] * world.y + vp->m[11] * world.z + vp->m[15];
    if (w <= 1e-6f)
        return 0;
    float ndc_x = x / w, ndc_y = y / w;
    out->x = (ndc_x * 0.5f + 0.5f) * sw;
    out->y = (1.0f - (ndc_y * 0.5f + 0.5f)) * sh;
    if (depth) *depth = z / w;
    return 1;
}

// direction -> Unity euler aim (pitch around X, yaw around Y), degrees
static inline void dir_to_angles(vec3 dir, float *pitch, float *yaw) {
    dir = v3_norm(dir);
    *pitch = -asinf(dir.y) * (180.0f / (float)M_PI);
    *yaw   =  atan2f(dir.x, dir.z) * (180.0f / (float)M_PI);
}

// shortest signed delta between two angles in degrees, result in (-180, 180]
static inline float angle_delta(float from, float to) {
    float d = fmodf(to - from, 360.0f);
    if (d > 180.0f) d -= 360.0f;
    if (d <= -180.0f) d += 360.0f;
    return d;
}

// frame-rate independent smoothing: 1 = instant, smaller = slower
static inline float smooth_step(float current, float target, float factor) {
    return current + angle_delta(current, target) * factor;
}

static inline float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

#endif
