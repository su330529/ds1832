// il2cpp.h — class discovery for a Unity/IL2CPP game, no hardcoded offsets
//
// everything here is derived at runtime:
//   1. locate the global-metadata blob by its magic
//   2. read the type definition table, resolve names out of the string blob
//   3. find the runtime Il2CppClass* by scanning for pointers into that blob
//   4. find live instances by scanning the heap for objects whose klass matches
#ifndef IL2CPP_H
#define IL2CPP_H

#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>

#define IL2CPP_MAGIC 0xFAB11BAFu

typedef struct {
    pid_t    pid;
    uint64_t base;          // global-metadata address
    uint64_t size;
    int32_t  version;
    int32_t  string_off,  string_size;
    int32_t  typedef_off, typedef_count;
    int32_t  typedef_size;  // bytes per entry, derived from the section size
} il2cpp_meta;

typedef struct {
    int32_t name_index;
    int32_t namespace_index;
    int32_t parent_index;
    uint32_t token;
    uint64_t name_ptr;      // name string inside the metadata blob
    uint64_t ns_ptr;
} il2cpp_type_def;

int  il2cpp_find_metadata(pid_t pid, uint64_t *base_out, uint64_t *size_out);
int  il2cpp_meta_parse(pid_t pid, uint64_t base, il2cpp_meta *m);
int  il2cpp_typedef(const il2cpp_meta *m, uint32_t index, il2cpp_type_def *out);

// exact match on namespace + name; returns the type definition index or -1
int  il2cpp_find_type(const il2cpp_meta *m, const char *ns, const char *name, il2cpp_type_def *out);
// substring search over every type name, for exploration
int  il2cpp_grep_types(const il2cpp_meta *m, const char *needle, int limit);

// runtime Il2CppClass*: its name/namespaze fields point into the metadata blob
uint64_t il2cpp_class_ptr(const il2cpp_meta *m, const char *ns, const char *name);

typedef int (*il2cpp_obj_cb)(pid_t pid, uint64_t obj, void *ctx);
// returns how many objects matched
int il2cpp_scan_instances(pid_t pid, uint64_t klass_ptr, il2cpp_obj_cb cb, void *ctx, int limit);

#endif
