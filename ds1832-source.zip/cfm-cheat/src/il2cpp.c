// il2cpp.c — see il2cpp.h
#include "il2cpp.h"
#include "kwr.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define CHUNK      (1u << 20)
#define HDR_PAIRS  24

// pair index inside Il2CppGlobalMetadataHeader (offset at 8 + 8*i, size next)
#define PAIR(i) (8 + (i) * 8)
#define P_STRING        2
#define P_TYPEDEFS      19

static int read_i32(pid_t pid, uint64_t va, int32_t *out) {
    return kwr_uread(pid, va, out, 4);
}

int il2cpp_find_metadata(pid_t pid, uint64_t *base_out, uint64_t *size_out) {
    uint8_t *buf = malloc(CHUNK);
    if (!buf) return -1;
    int found = -1;

    uint64_t cursor = 0, start = 0, size = 0;
    uint32_t prot = 0;
    while (kwr_region_next(pid, &cursor, &start, &size, &prot) == 0) {
        if (!size || !(prot & 1))
            continue;
        for (uint64_t off = 0; off < size; off += CHUNK) {
            size_t want = (size_t)((size - off < CHUNK) ? (size - off) : CHUNK);
            if (kwr_uread(pid, start + off, buf, want) != 0)
                break;
            for (size_t i = 0; i + 4 <= want; i += 4) {
                uint32_t w;
                memcpy(&w, buf + i, 4);
                if (w != IL2CPP_MAGIC)
                    continue;
                uint64_t cand = start + off + i;
                uint32_t magic = 0;
                int32_t ver = 0, str_off = 0, str_size = 0, td_off = 0, td_size = 0;
                if (kwr_uread(pid, cand, &magic, 4) != 0) continue;
                if (read_i32(pid, cand + 4, &ver) != 0) continue;
                if (ver < 16 || ver > 35) continue;      // v16..v35 covers iOS 12..18
                if (read_i32(pid, cand + PAIR(P_STRING) + 0, &str_off) != 0) continue;
                if (read_i32(pid, cand + PAIR(P_STRING) + 4, &str_size) != 0) continue;
                if (read_i32(pid, cand + PAIR(P_TYPEDEFS) + 0, &td_off) != 0) continue;
                if (read_i32(pid, cand + PAIR(P_TYPEDEFS) + 4, &td_size) != 0) continue;
                if (str_off <= 0 || str_size <= 0 || td_off <= 0 || td_size <= 0) continue;
                if (str_off > (1 << 28) || td_off > (1 << 28)) continue;

                if (base_out) *base_out = cand;
                if (size_out) *size_out = ((uint64_t)td_off + (uint64_t)td_size) + 0x1000;
                found = 0;
                goto done;
            }
        }
    }
done:
    free(buf);
    return found;
}

int il2cpp_meta_parse(pid_t pid, uint64_t base, il2cpp_meta *m) {
    memset(m, 0, sizeof(*m));
    m->pid = pid;
    m->base = base;

    uint32_t magic = 0;
    if (kwr_uread(pid, base, &magic, 4) != 0 || magic != IL2CPP_MAGIC)
        return -1;
    read_i32(pid, base + 4, &m->version);

    if (read_i32(pid, base + PAIR(P_STRING) + 0, &m->string_off) != 0) return -2;
    if (read_i32(pid, base + PAIR(P_STRING) + 4, &m->string_size) != 0) return -2;
    if (read_i32(pid, base + PAIR(P_TYPEDEFS) + 0, &m->typedef_off) != 0) return -3;
    int32_t td_bytes = 0;
    if (read_i32(pid, base + PAIR(P_TYPEDEFS) + 4, &td_bytes) != 0) return -3;
    if (td_bytes <= 0 || m->string_size <= 0) return -4;

    // derive both count and stride from the section size: no layout constants.
    // sizeof(Il2CppTypeDefinition) is 92 on v27+, 88 on v24-v26, 84 on older;
    // pick the first candidate that divides the section exactly.
    static const int32_t candidates[] = {92, 88, 84, 96, 100, 104};
    int32_t count = 0, stride_used = 0;
    for (unsigned i = 0; i < sizeof(candidates) / sizeof(candidates[0]); i++) {
        if (td_bytes % candidates[i] == 0 && td_bytes / candidates[i] > 0) {
            count = td_bytes / candidates[i];
            stride_used = candidates[i];
            break;
        }
    }
    if (!count) return -5;
    m->typedef_count = count;
    m->typedef_size = stride_used;
    return 0;
}

static uint64_t str_ptr(const il2cpp_meta *m, int32_t index) {
    if (index < 0 || index >= m->string_size) return 0;
    return m->base + (uint64_t)m->string_off + (uint64_t)index;
}

int il2cpp_typedef(const il2cpp_meta *m, uint32_t index, il2cpp_type_def *out) {
    if ((int32_t)index >= m->typedef_count) return -1;
    uint64_t va = m->base + (uint64_t)m->typedef_off + (uint64_t)index * (uint64_t)m->typedef_size;
    uint8_t raw[128];
    if (kwr_uread(m->pid, va, raw, (size_t)m->typedef_size) != 0) return -2;

    memset(out, 0, sizeof(*out));
    memcpy(&out->name_index, raw + 0, 4);
    memcpy(&out->namespace_index, raw + 4, 4);
    memcpy(&out->parent_index, raw + 20, 4);
    // token sits 4 bytes before the end of the struct on v27+
    if (m->typedef_size >= 92)
        memcpy(&out->token, raw + m->typedef_size - 4, 4);
    out->name_ptr = str_ptr(m, out->name_index);
    out->ns_ptr = str_ptr(m, out->namespace_index);
    return 0;
}

int il2cpp_find_type(const il2cpp_meta *m, const char *ns, const char *name, il2cpp_type_def *out) {
    char nb[256], sb[256];
    for (int32_t i = 0; i < m->typedef_count; i++) {
        il2cpp_type_def d;
        if (il2cpp_typedef(m, (uint32_t)i, &d) != 0)
            continue;
        if (!d.name_ptr)
            continue;
        if (kwr_ustring(m->pid, d.name_ptr, nb, sizeof(nb)) < 0)
            continue;
        if (strcmp(nb, name))
            continue;
        sb[0] = 0;
        if (d.ns_ptr)
            kwr_ustring(m->pid, d.ns_ptr, sb, sizeof(sb));
        if (strcmp(sb, ns))
            continue;
        if (out) *out = d;
        return i;
    }
    return -1;
}

int il2cpp_grep_types(const il2cpp_meta *m, const char *needle, int limit) {
    char nb[256], sb[256];
    int hits = 0;
    for (int32_t i = 0; i < m->typedef_count && hits < limit; i++) {
        il2cpp_type_def d;
        if (il2cpp_typedef(m, (uint32_t)i, &d) != 0 || !d.name_ptr)
            continue;
        if (kwr_ustring(m->pid, d.name_ptr, nb, sizeof(nb)) < 0)
            continue;
        if (!strstr(nb, needle))
            continue;
        sb[0] = 0;
        if (d.ns_ptr) kwr_ustring(m->pid, d.ns_ptr, sb, sizeof(sb));
        printf("  [%5d] %s%s%s  (token 0x%08x)\n", i,
               sb[0] ? sb : "", sb[0] ? "::" : "", nb, d.token);
        hits++;
    }
    return hits;
}

uint64_t il2cpp_class_ptr(const il2cpp_meta *m, const char *ns, const char *name) {
    il2cpp_type_def d;
    if (il2cpp_find_type(m, ns, name, &d) != 0 || !d.name_ptr)
        return 0;

    // Il2CppClass: image @0, gc_desc @8, name @0x10, namespaze @0x18
    uint8_t *buf = malloc(CHUNK);
    if (!buf) return 0;
    uint64_t hit = 0;

    uint64_t cursor = 0, start = 0, size = 0;
    uint32_t prot = 0;
    while (kwr_region_next(m->pid, &cursor, &start, &size, &prot) == 0) {
        if (!size || !(prot & 1)) continue;
        for (uint64_t off = 0; off < size && !hit; off += CHUNK) {
            size_t want = (size_t)((size - off < CHUNK) ? (size - off) : CHUNK);
            if (kwr_uread(m->pid, start + off, buf, want) != 0)
                break;
            for (size_t i = 0; i + 8 <= want; i += 8) {
                uint64_t v;
                memcpy(&v, buf + i, 8);
                if (v != d.name_ptr)
                    continue;
                uint64_t cand = start + off + i - 0x10;   // name field is at +0x10
                uint64_t ns_field = 0;
                if (kwr_uread(m->pid, cand + 0x18, &ns_field, 8) != 0)
                    continue;
                if (ns_field != d.ns_ptr)
                    continue;
                uint64_t image = 0;
                if (kwr_uread(m->pid, cand, &image, 8) != 0 || !image)
                    continue;
                hit = cand;
                break;
            }
        }
        if (hit) break;
    }
    free(buf);
    return hit;
}

int il2cpp_scan_instances(pid_t pid, uint64_t klass_ptr, il2cpp_obj_cb cb, void *ctx, int limit) {
    uint8_t *buf = malloc(CHUNK);
    if (!buf) return 0;
    int found = 0;

    uint64_t cursor = 0, start = 0, size = 0;
    uint32_t prot = 0;
    while (kwr_region_next(pid, &cursor, &start, &size, &prot) == 0 && found < limit) {
        if (!size || !(prot & 2))            // writable regions = managed heap
            continue;
        for (uint64_t off = 0; off < size && found < limit; off += CHUNK) {
            size_t want = (size_t)((size - off < CHUNK) ? (size - off) : CHUNK);
            if (kwr_uread(pid, start + off, buf, want) != 0)
                break;
            for (size_t i = 0; i + 8 <= want; i += 8) {
                uint64_t v;
                memcpy(&v, buf + i, 8);
                if (v != klass_ptr)
                    continue;
                uint64_t obj = start + off + i;
                // Il2CppObject: klass @0, monitor @8 — the object starts here
                if (cb && cb(pid, obj, ctx) != 0)
                    found++;
                else if (!cb)
                    found++;
                if (found >= limit)
                    break;
            }
        }
    }
    free(buf);
    return found;
}
