// cfm_offsets.h — EVERYTHING here comes from your own dump of your own build.
//
// do not paste offsets from a forum post: they are build-specific and a wrong
// offset does not "not work", it corrupts the process and gets you a crash or a
// ban. fill these after analysing the dump (see README, stage 2).
#ifndef CFM_OFFSETS_H
#define CFM_OFFSETS_H

// --- angles ---
// offset inside the euler-angle float triple in the local player's aim state
#define CFM_OFF_ANGLE_PITCH   0x0
#define CFM_OFF_ANGLE_YAW     0x4
#define CFM_OFF_ANGLE_ROLL    0x8
#define CFM_WRITE_ROLL        0

// --- camera ---
// worldToCameraMatrix is a 16-float column-major block, projectionMatrix likewise
#define CFM_OFF_VIEW_MATRIX    0x0   // TODO: from dump
#define CFM_OFF_PROJ_MATRIX    0x0   // TODO: from dump
#define CFM_OFF_CAMERA_POS     0x0   // TODO: vec3 world position

// --- entity list ---
#define CFM_OFF_ENTITY_LIST    0x0   // TODO: pointer to the first entity
#define CFM_OFF_ENTITY_STRIDE  0x0   // TODO: pointer size per slot
#define CFM_OFF_ENTITY_COUNT   0x0   // TODO: int32 count
#define CFM_OFF_ENTITY_TEAM    0x0   // TODO: int32 team id
#define CFM_OFF_ENTITY_HEALTH  0x0   // TODO: float hp
#define CFM_OFF_ENTITY_POS     0x0   // TODO: vec3 root position
#define CFM_OFF_ENTITY_HEAD    0x0   // TODO: vec3 head position (or bone matrix + index)

// --- recoil / spread ---
#define CFM_OFF_RECOIL         0x0   // TODO: float, write 0
#define CFM_OFF_SPREAD         0x0   // TODO: float, write 0

// --- tuning ---
#define CFM_FOV_DEG            18.0f
#define CFM_MAX_DISTANCE       250.0f
#define CFM_AIM_SMOOTH         0.35f

#endif
