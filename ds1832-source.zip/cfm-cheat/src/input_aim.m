// input_aim.m — crosshair assist by synthesising touches, not by writing game memory
//
// why this shape: install.ipa imports
//     GSEventInitialize / GSEventPushRunLoopMode / BKSDisplayServicesStart
//     BKSHIDEventRegisterEventCallback
//     IOHIDEventCreateDigitizerFingerEventWithQuality / IOHIDEventAppendEvent
// i.e. the aim is a *finger drag* the game accepts as real input. that sidesteps
// every integrity check that would notice a patched aim angle.
//
// entitlement gate: com.apple.private.hid.client.event-dispatch / event-filter,
// com.apple.backboardd.global-pointer-event-routing, com.apple.accessibility.api.
//
// semantics: hold = finger down, move = drag to the target, release = lift.
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <objc/message.h>
#import <dlfcn.h>
#import <mach/mach.h>

typedef struct {
    float    dx, dy;      // normalised delta applied per step
    CGFloat  step_px;     // pixels per injection step
    int      steps;       // how many steps to reach the target
    NSTimeInterval interval;
} DMAimProfile;

@interface DSInput : NSObject
+ (BOOL)start;
+ (BOOL)available;
// drag from the current crosshair towards a screen-space target
+ (void)touchDownAt:(CGPoint)p;
+ (void)touchMoveTo:(CGPoint)p;
+ (void)touchUpAt:(CGPoint)p;
+ (void)aimFrom:(CGPoint)from to:(CGPoint)to profile:(DMAimProfile)p;
@end

// ---- private entry points, resolved by name ------------------------------
static void *(*p_GSEventInitialize)(int) = NULL;
static int  (*p_GSEventPushRunLoopMode)(void *) = NULL;
static void *(*p_IOHIDEventCreateDigitizerFingerEventWithQuality)(
        void *, uint64_t, uint32_t, uint32_t, uint32_t, double,
        double, double, double, double, double, double, double, double, uint32_t, uint32_t) = NULL;
static void (*p_IOHIDEventAppendEvent)(void *, void *, uint32_t) = NULL;
static void (*p_IOHIDEventSetIntegerValue)(void *, uint32_t, int32_t) = NULL;
static int  (*p_BKSDisplayServicesStart)(void) = NULL;

@implementation DSInput

+ (BOOL)start {
    if (!p_GSEventInitialize) {
        void *h = dlopen("/System/Library/PrivateFrameworks/GraphicsServices.framework/GraphicsServices",
                         RTLD_NOW);
        if (h) {
            p_GSEventInitialize = dlsym(h, "GSEventInitialize");
            p_GSEventPushRunLoopMode = dlsym(h, "GSEventPushRunLoopMode");
        }
    }
    if (!p_IOHIDEventCreateDigitizerFingerEventWithQuality) {
        void *h = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW);
        if (h) {
            p_IOHIDEventCreateDigitizerFingerEventWithQuality =
                dlsym(h, "IOHIDEventCreateDigitizerFingerEventWithQuality");
            p_IOHIDEventAppendEvent = dlsym(h, "IOHIDEventAppendEvent");
            p_IOHIDEventSetIntegerValue = dlsym(h, "IOHIDEventSetIntegerValue");
        }
    }
    if (!p_BKSDisplayServicesStart) {
        void *h = dlopen("/System/Library/PrivateFrameworks/BackBoardServices.framework/BackBoardServices",
                         RTLD_NOW);
        if (h) p_BKSDisplayServicesStart = dlsym(h, "BKSDisplayServicesStart");
    }

    if (p_BKSDisplayServicesStart) p_BKSDisplayServicesStart();
    if (p_GSEventInitialize)      p_GSEventInitialize(0);
    if (p_GSEventPushRunLoopMode) p_GSEventPushRunLoopMode((__bridge void *)NSDefaultRunLoopMode);

    NSLog(@"[ds] input: gs=%d hid=%d bks=%d", !!p_GSEventInitialize,
          !!p_IOHIDEventCreateDigitizerFingerEventWithQuality, !!p_BKSDisplayServicesStart);
    return p_IOHIDEventCreateDigitizerFingerEventWithQuality != NULL;
}

+ (BOOL)available { return p_IOHIDEventCreateDigitizerFingerEventWithQuality != NULL; }

// phase: 1 = down, 2 = move, 4 = up (IOHID digitizer semantics)
+ (void)postFinger:(CGPoint)p phase:(uint32_t)phase {
    if (!p_IOHIDEventCreateDigitizerFingerEventWithQuality) return;

    void *ev = p_IOHIDEventCreateDigitizerFingerEventWithQuality(
        kCFAllocatorDefault,
        0,                    // timestamp 0 = now
        1,                    // index
        1,                    // identity
        phase,
        p.x, p.y,
        1.0, 1.0,             // pressure
        1.0, 1.0,             // twist
        1.0, 1.0,             // major/minor radius
        0.0, 0.0,             // quality
        1, 0);                // options, mask
    if (!ev) return;
    // the host that owns the display link dispatches this; see README stage 3
    (void)p_IOHIDEventAppendEvent;
    CFRelease(ev);
}

+ (void)touchDownAt:(CGPoint)p { [self postFinger:p phase:1]; }
+ (void)touchMoveTo:(CGPoint)p { [self postFinger:p phase:2]; }
+ (void)touchUpAt:(CGPoint)p   { [self postFinger:p phase:4]; }

+ (void)aimFrom:(CGPoint)from to:(CGPoint)to profile:(DMAimProfile)p {
    if (![self available]) return;
    [self touchDownAt:from];
    CGFloat dx = (to.x - from.x) / (p.steps > 0 ? p.steps : 1);
    CGFloat dy = (to.y - from.y) / (p.steps > 0 ? p.steps : 1);
    CGPoint cur = from;
    for (int i = 0; i < p.steps; i++) {
        cur.x += dx;
        cur.y += dy;
        [self touchMoveTo:cur];
        [NSThread sleepForTimeInterval:p.interval];
    }
    [self touchUpAt:cur];
}

@end
