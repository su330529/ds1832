// dump.h — pull memory out of the target so the offsets can be found offline
#ifndef DUMP_H
#define DUMP_H

#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>

#define VM_PROT_READ_  1
#define VM_PROT_WRITE_ 2
#define VM_PROT_EXEC_  4

int dump_list_regions(pid_t pid);
// first readable region whose first 4 bytes are a 64-bit Mach-O magic
int dump_find_macho(pid_t pid, uint64_t *base_out, uint64_t *size_out);
int dump_range(pid_t pid, uint64_t va, size_t len, const char *path);
int dump_search_ascii(pid_t pid, const char *needle, int limit, int skip_exec);

#endif
