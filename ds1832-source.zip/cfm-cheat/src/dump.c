// dump.c — see dump.h
#include "dump.h"
#include "kwr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHUNK (1u << 20)

int dump_list_regions(pid_t pid) {
    uint64_t cursor = 0, start = 0, size = 0;
    uint32_t prot = 0;
    int n = 0;
    printf("  start              end                size        prot\n");
    while (kwr_region_next(pid, &cursor, &start, &size, &prot) == 0) {
        printf("  %016llx  %016llx  %10llu  %s%s%s\n",
               (unsigned long long)start, (unsigned long long)(start + size),
               (unsigned long long)size,
               (prot & 1) ? "r" : "-", (prot & 2) ? "w" : "-", (prot & 4) ? "x" : "-");
        n++;
    }
    printf("  %d regions\n", n);
    return n;
}

int dump_find_macho(pid_t pid, uint64_t *base_out, uint64_t *size_out) {
    uint64_t cursor = 0, start = 0, size = 0;
    uint32_t prot = 0;
    while (kwr_region_next(pid, &cursor, &start, &size, &prot) == 0) {
        if (!(prot & 1) || size < 0x1000)
            continue;
        uint32_t magic = 0;
        if (kwr_uread(pid, start, &magic, 4) != 0)
            continue;
        if (magic == 0xfeedfacfu) {           // MH_MAGIC_64
            if (base_out) *base_out = start;
            if (size_out) *size_out = size;
            return 0;
        }
    }
    return -1;
}

int dump_range(pid_t pid, uint64_t va, size_t len, const char *path) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    uint8_t *buf = malloc(CHUNK);
    if (!buf) { fclose(f); return -1; }

    size_t done = 0;
    while (done < len) {
        size_t want = len - done < CHUNK ? len - done : CHUNK;
        if (kwr_uread(pid, va + done, buf, want) != 0) {
            // keep the dump usable: zero-fill the unreadable tail and stop
            memset(buf, 0, want);
            fwrite(buf, 1, want, f);
            done += want;
            fprintf(stderr, "dump: unreadable at +0x%zx, zero-filled\n", done);
            break;
        }
        fwrite(buf, 1, want, f);
        done += want;
    }
    free(buf);
    fclose(f);
    printf("dumped 0x%zx bytes from 0x%llx -> %s\n", done, (unsigned long long)va, path);
    return 0;
}

int dump_search_ascii(pid_t pid, const char *needle, int limit, int skip_exec) {
    size_t nl = strlen(needle);
    if (!nl) return 0;
    uint8_t *buf = malloc(CHUNK + nl);
    if (!buf) return 0;

    int hits = 0;
    uint64_t cursor = 0, start = 0, size = 0;
    uint32_t prot = 0;
    while (kwr_region_next(pid, &cursor, &start, &size, &prot) == 0 && hits < limit) {
        if (!(prot & 1)) continue;
        if (skip_exec && (prot & 4)) continue;
        for (uint64_t off = 0; off < size && hits < limit; off += CHUNK) {
            size_t want = (size_t)((size - off < CHUNK) ? (size - off) : CHUNK);
            if (kwr_uread(pid, start + off, buf, want) != 0)
                break;
            buf[want] = 0;
            for (size_t i = 0; i + nl <= want; i++) {
                if (memcmp(buf + i, needle, nl) == 0) {
                    printf("  0x%016llx  (+0x%zx in region 0x%llx)\n",
                           (unsigned long long)(start + off + i), i, (unsigned long long)start);
                    hits++;
                    if (hits >= limit) break;
                }
            }
        }
    }
    free(buf);
    return hits;
}
