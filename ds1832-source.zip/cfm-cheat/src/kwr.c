// kwr.c — thin dispatch over whichever backend is registered
#include "kwr.h"
#include <string.h>

static const kwr_backend *g_backend = NULL;

int kwr_register(const kwr_backend *b) {
    if (!b || !b->kread || !b->kwrite)
        return -1;
    g_backend = b;
    return 0;
}

const kwr_backend *kwr_active(void) { return g_backend; }

int kwr_kread(uint64_t kva, void *buf, size_t len) {
    if (!g_backend) return -1;
    return g_backend->kread(kva, buf, len);
}

int kwr_kwrite(uint64_t kva, const void *buf, size_t len) {
    if (!g_backend) return -1;
    return g_backend->kwrite(kva, buf, len);
}

int kwr_uread(pid_t pid, uint64_t uva, void *buf, size_t len) {
    if (!g_backend || !g_backend->uva_read) return -1;
    return g_backend->uva_read(pid, uva, buf, len);
}

int kwr_uwrite(pid_t pid, uint64_t uva, const void *buf, size_t len) {
    if (!g_backend || !g_backend->uva_write) return -1;
    return g_backend->uva_write(pid, uva, buf, len);
}

uint8_t kwr_u8(pid_t pid, uint64_t uva) {
    uint8_t v = 0;
    kwr_uread(pid, uva, &v, 1);
    return v;
}

uint32_t kwr_u32(pid_t pid, uint64_t uva) {
    uint32_t v = 0;
    kwr_uread(pid, uva, &v, 4);
    return v;
}

uint64_t kwr_u64(pid_t pid, uint64_t uva) {
    uint64_t v = 0;
    kwr_uread(pid, uva, &v, 8);
    return v;
}

float kwr_f32(pid_t pid, uint64_t uva) {
    float v = 0;
    kwr_uread(pid, uva, &v, 4);
    return v;
}

int kwr_uwrite_u64(pid_t pid, uint64_t uva, uint64_t v) {
    return kwr_uwrite(pid, uva, &v, 8);
}

int kwr_uwrite_f32(pid_t pid, uint64_t uva, float v) {
    return kwr_uwrite(pid, uva, &v, 4);
}

uint64_t kwr_kread64(uint64_t kva) {
    uint64_t v = 0;
    kwr_kread(kva, &v, 8);
    return v;
}

int kwr_kwrite64(uint64_t kva, uint64_t v) {
    return kwr_kwrite(kva, &v, 8);
}

int kwr_region_next(pid_t pid, uint64_t *cursor, uint64_t *start, uint64_t *size, uint32_t *prot) {
    if (!g_backend || !g_backend->region_next) return 1;
    return g_backend->region_next(pid, cursor, start, size, prot);
}

int kwr_ustring(pid_t pid, uint64_t uva, char *out, size_t cap) {
    if (!cap) return -1;
    size_t i = 0;
    while (i + 1 < cap) {
        char c;
        if (kwr_uread(pid, uva + i, &c, 1) != 0)
            break;
        out[i] = c;
        if (!c) return (int)i;
        i++;
    }
    out[i] = 0;
    return (int)i;
}
