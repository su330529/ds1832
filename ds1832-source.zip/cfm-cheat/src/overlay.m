// overlay.m — cross-app overlay host via CAContext (the technique install.ipa uses)
//
// what the analysed binary does, in order:
//   [CAContext remoteContextWithOptions:]  -> a context owned by the window server
//   window.layer.context = that context      -> our layer tree renders outside the app
//   [CAWindowServer registerWindowWithContextID:atLevel:]  -> put it above the game
//   ignoresHitTest = YES                     -> touches pass through to the game
//
// entitlement gate: com.apple.QuartzCore.displayable-context + com.apple.backboard.client
// without those the context comes back nil and nothing appears. a free personal cert
// cannot carry them; this needs a provisioning profile that does.
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <dlfcn.h>
#import <objc/message.h>
#import <os/lock.h>

@interface DSOverlay : NSObject
@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong) CALayer *root;
- (BOOL)start;
- (void)stop;
- (void)render:(void (^)(CALayer *root, CGFloat scale))block;
@end

// private symbols, resolved lazily so a missing one fails soft instead of crashing
static Class      CAContextClass(void)      { return NSClassFromString(@"CAContext"); }
static Class      CAWindowServerClass(void) { return NSClassFromString(@"CAWindowServer"); }

@implementation DSOverlay {
    id _context;
}

- (BOOL)start {
    Class ctxCls = CAContextClass();
    if (!ctxCls || ![ctxCls respondsToSelector:NSSelectorFromString(@"remoteContextWithOptions:")]) {
        NSLog(@"[ds] CAContext unavailable — entitlement com.apple.QuartzCore.displayable-context missing?");
        return NO;
    }

    NSDictionary *opts = @{
        @"kCAContextIgnoresHitTest": @YES,      // let touches reach the game underneath
        @"kCAContextDisplayable":    @YES,
        @"kCAContextDisplayName":    @"ds-overlay",
    };
    _context = ((id (*)(id, SEL, id))objc_msgSend)(ctxCls,
                 NSSelectorFromString(@"remoteContextWithOptions:"), opts);
    if (!_context) {
        NSLog(@"[ds] remoteContextWithOptions returned nil (not entitled)");
        return NO;
    }

    uint32_t contextId = ((uint32_t (*)(id, SEL))objc_msgSend)(_context,
                          NSSelectorFromString(@"contextId"));
    NSLog(@"[ds] CAContext 0x%x", contextId);

    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.windowLevel = UIWindowLevelStatusBar + 1;
    self.window.hidden = NO;
    self.window.backgroundColor = [UIColor clearColor];
    self.window.userInteractionEnabled = NO;      // never steal input

    self.root = [CALayer layer];
    self.root.frame = self.window.bounds;
    self.root.contentsScale = [UIScreen mainScreen].scale;
    [self.window.layer addSublayer:self.root];

    // move the window's layer into the remote context
    if ([self.window.layer respondsToSelector:NSSelectorFromString(@"setContext:")]) {
        ((void (*)(id, SEL, id))objc_msgSend)(self.window.layer,
            NSSelectorFromString(@"setContext:"), _context);
    } else {
        NSLog(@"[ds] CALayer has no setContext: — cannot attach");
        return NO;
    }

    [self.window makeKeyAndVisible];

    // tell the window server where this context sits in the stack
    Class wsCls = CAWindowServerClass();
    if (wsCls) {
        id server = ((id (*)(id, SEL))objc_msgSend)(wsCls, NSSelectorFromString(@"serverIfNecessary"));
        SEL reg = NSSelectorFromString(@"registerWindowWithContextID:atLevel:");
        if (server && [server respondsToSelector:reg]) {
            ((void (*)(id, SEL, uint32_t, float))objc_msgSend)(server, reg,
                contextId, (float)(UIWindowLevelStatusBar + 1));
            NSLog(@"[ds] registered context 0x%x with the window server", contextId);
        }
    }
    return YES;
}

- (void)render:(void (^)(CALayer *root, CGFloat scale))block {
    if (!self.root || !block) return;
    block(self.root, [UIScreen mainScreen].scale);
}

- (void)stop {
    [self.window setHidden:YES];
    self.window = nil;
    self.root = nil;
    _context = nil;
}

@end
