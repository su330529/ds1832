// aim.h — target selection and the write path for a silent-aim style assist
//
// the cheat never calls game code. it writes the two floats the engine itself
// uses to build the shot direction, which is why this survives without injection.
#ifndef AIM_H
#define AIM_H

#include "math3d.h"
#include <sys/types.h>

typedef enum { BONE_HEAD = 0, BONE_CHEST, BONE_PELVIS } aim_bone;

typedef struct {
    uint64_t obj;         // entity object address
    vec3     head;        // world position of the chosen bone
    vec3     root;        // feet/root, used to size the ESP box
    float    distance;
    int      alive;
    int      visible;     // caller fills this if it can raytrace, else leave 1
} aim_target;

typedef struct {
    float fov_deg;        // only consider targets inside this cone
    float max_distance;   // metres
    aim_bone bone;        // preferred hitbox
    float smooth;         // 0.05 slow ... 1.0 instant
    int   require_visible;
} aim_config;

typedef struct {
    float pitch;
    float yaw;
} aim_angles;

// picks the best candidate: closest angular distance inside the FOV, then distance
int aim_pick(const aim_config *cfg, const aim_angles *current,
             const aim_target *targets, int n, vec3 eye, int *chosen);

// computes the next angles to write, respecting smoothing
int aim_compute(const aim_config *cfg, const aim_angles *current,
                const aim_target *target, vec3 eye, aim_angles *out);

// writes the pair into the target process; layout comes from cfm_offsets.h
int aim_apply(pid_t pid, uint64_t angles_field, const aim_angles *a);

#endif
