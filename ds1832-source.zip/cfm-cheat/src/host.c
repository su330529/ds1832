// host.c — command surface over the cheat layer
//
// this file deliberately does not contain an exploit. it runs inside whatever
// process already holds kernel read/write (our ds1832 chain, or a host that
// exposes KWR). call cfm_host_cmd() from that process's UI.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

#include "kwr.h"
#include "macho.h"
#include "il2cpp.h"
#include "dump.h"

// provided by the host that links this library; returns 0 when KWR is live
extern int cfm_backend_attach(void);

static int rd_cb(void *ctx, uint64_t va, void *buf, size_t len) {
    pid_t pid = *(pid_t *)ctx;
    return kwr_uread(pid, va, buf, len);
}

static void cmd_meta(pid_t pid) {
    uint64_t base = 0, size = 0;
    if (il2cpp_find_metadata(pid, &base, &size) != 0) {
        printf("global-metadata: not found (is this the Unity process?)\n");
        return;
    }
    il2cpp_meta m;
    if (il2cpp_meta_parse(pid, base, &m) != 0) {
        printf("global-metadata at 0x%llx but header parse failed\n", (unsigned long long)base);
        return;
    }
    printf("global-metadata: 0x%llx  version %d\n", (unsigned long long)base, m.version);
    printf("  string blob  : +0x%x (%d bytes)\n", m.string_off, m.string_size);
    printf("  type defs    : +0x%x  %d entries x %d bytes\n",
           m.typedef_off, m.typedef_count, m.typedef_size);
}

static void cmd_exports(pid_t pid) {
    uint64_t base = 0, size = 0;
    if (dump_find_macho(pid, &base, &size) != 0) {
        printf("no Mach-O image found\n");
        return;
    }
    macho_t m;
    if (macho_parse(rd_cb, &pid, base, &m) != 0) {
        printf("macho parse failed at 0x%llx\n", (unsigned long long)base);
        return;
    }
    printf("image at 0x%llx filetype=%u ncmds=%u segs=%d sections=%d\n",
           (unsigned long long)base, m.filetype, m.ncmds, m.nsegs, m.nsects);
    for (int i = 0; i < m.nsegs; i++)
        printf("  seg %-16s 0x%llx +0x%llx\n", m.segs[i].seg,
               (unsigned long long)m.segs[i].vmaddr, (unsigned long long)m.segs[i].vmsize);

    static const char *syms[] = {
        "il2cpp_domain_get_assemblies",
        "il2cpp_class_from_name",
        "il2cpp_class_get_field_from_name",
        "il2cpp_field_get_offset",
        "il2cpp_object_get_class",
        "il2cpp_gchandle_get_target",
    };
    printf("exports:\n");
    for (unsigned i = 0; i < sizeof(syms) / sizeof(syms[0]); i++) {
        uint64_t a = macho_lookup_export(&m, syms[i]);
        printf("  %-34s %s0x%llx\n", syms[i], a ? "" : "(missing) ",
               (unsigned long long)a);
    }
}

static void cmd_class(pid_t pid, const char *ns, const char *name) {
    uint64_t base = 0, size = 0;
    if (il2cpp_find_metadata(pid, &base, &size) != 0) { printf("no metadata\n"); return; }
    il2cpp_meta m;
    if (il2cpp_meta_parse(pid, base, &m) != 0) { printf("header parse failed\n"); return; }

    int idx = il2cpp_find_type(&m, ns, name, NULL);
    if (idx < 0) { printf("type %s::%s not found\n", ns, name); return; }
    printf("type %s::%s at index %d\n", ns, name, idx);

    uint64_t klass = il2cpp_class_ptr(&m, ns, name);
    if (!klass) { printf("  runtime Il2CppClass not found in memory\n"); return; }
    printf("  Il2CppClass* = 0x%llx\n", (unsigned long long)klass);
    int n = il2cpp_scan_instances(pid, klass, NULL, NULL, 32);
    printf("  live instances (capped): %d\n", n);
}

static void usage(void) {
    printf(
        "cfm_host commands:\n"
        "  regions <pid>                     list mappings\n"
        "  exports <pid>                     parse image + il2cpp export addresses\n"
        "  meta <pid>                        locate global-metadata\n"
        "  find <pid> <substring>            grep class names\n"
        "  class <pid> <namespace> <name>    resolve class + count instances\n"
        "  strings <pid> <needle>            ascii search across readable memory\n"
        "  dump <pid> <va> <len> <path>      dump raw memory to a file\n");
}

int cfm_host_cmd(const char *line) {
    char buf[512];
    snprintf(buf, sizeof(buf), "%s", line);

    char *argv[8] = {0};
    int argc = 0;
    for (char *t = strtok(buf, " "); t && argc < 8; t = strtok(NULL, " "))
        argv[argc++] = t;
    if (argc < 2) { usage(); return -1; }

    if (cfm_backend_attach() != 0) {
        printf("KWR backend unavailable — nothing to talk to\n");
        return -1;
    }
    pid_t pid = (pid_t)atoi(argv[1]);

    if (!strcmp(argv[0], "regions"))       { dump_list_regions(pid); return 0; }
    if (!strcmp(argv[0], "exports"))       { cmd_exports(pid); return 0; }
    if (!strcmp(argv[0], "meta"))          { cmd_meta(pid); return 0; }
    if (!strcmp(argv[0], "class") && argc >= 4) {
        cmd_class(pid, argv[2], argv[3]);
        return 0;
    }
    if (!strcmp(argv[0], "find") && argc >= 3) {
        uint64_t base = 0, size = 0;
        if (il2cpp_find_metadata(pid, &base, &size) != 0) { printf("no metadata\n"); return -1; }
        il2cpp_meta m;
        if (il2cpp_meta_parse(pid, base, &m) != 0) { printf("parse failed\n"); return -1; }
        int n = il2cpp_grep_types(&m, argv[2], 60);
        printf("%d matches\n", n);
        return 0;
    }
    if (!strcmp(argv[0], "strings") && argc >= 3) {
        int n = dump_search_ascii(pid, argv[2], 40, 1);
        printf("%d hits\n", n);
        return 0;
    }
    if (!strcmp(argv[0], "dump") && argc >= 5) {
        dump_range(pid, strtoull(argv[2], NULL, 0), (size_t)strtoull(argv[3], NULL, 0), argv[4]);
        return 0;
    }
    usage();
    return -1;
}
