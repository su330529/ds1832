// kwr.h — kernel/user memory access surface the cheat layer needs
//
// the cheat logic never talks to a specific exploit. it asks kwr_* for bytes.
// backends: ds1832 (own kernel race chain) or any host that already holds KWR.
#ifndef KWR_H
#define KWR_H

#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>

typedef struct {
    const char *name;
    int (*kread)(uint64_t kva, void *buf, size_t len);
    int (*kwrite)(uint64_t kva, const void *buf, size_t len);
    int (*uva_read)(pid_t pid, uint64_t uva, void *buf, size_t len);
    int (*uva_write)(pid_t pid, uint64_t uva, const void *buf, size_t len);
    // optional: physical read, used to seed page-table walks
    int (*phys_read)(uint64_t pa, void *buf, size_t len);
    // optional: walk the target's mappings.
    // start with *cursor = 0; returns 0 while a region was returned, 1 at the end.
    int (*region_next)(pid_t pid, uint64_t *cursor, uint64_t *start, uint64_t *size, uint32_t *prot);
} kwr_backend;

int  kwr_register(const kwr_backend *b);
const kwr_backend *kwr_active(void);

int  kwr_kread(uint64_t kva, void *buf, size_t len);
int  kwr_kwrite(uint64_t kva, const void *buf, size_t len);
int  kwr_uread(pid_t pid, uint64_t uva, void *buf, size_t len);
int  kwr_uwrite(pid_t pid, uint64_t uva, const void *buf, size_t len);

uint8_t  kwr_u8(pid_t pid, uint64_t uva);
uint32_t kwr_u32(pid_t pid, uint64_t uva);
uint64_t kwr_u64(pid_t pid, uint64_t uva);
float    kwr_f32(pid_t pid, uint64_t uva);
int      kwr_uwrite_u64(pid_t pid, uint64_t uva, uint64_t v);
int      kwr_uwrite_f32(pid_t pid, uint64_t uva, float v);

uint64_t kwr_kread64(uint64_t kva);
int      kwr_kwrite64(uint64_t kva, uint64_t v);

// region walk wrapper; same contract as the backend callback
int kwr_region_next(pid_t pid, uint64_t *cursor, uint64_t *start, uint64_t *size, uint32_t *prot);

// reads a NUL-terminated string from the target process; returns length or -1
int kwr_ustring(pid_t pid, uint64_t uva, char *out, size_t cap);

#endif
