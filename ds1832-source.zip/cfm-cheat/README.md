# cfm-cheat — CFM 内核层数据外挂（A15 / iOS 18.3.2）

`iPhone14,3` · A15 · iOS 18.3.2 · 宿主：ds1832 内核读写链 / 任何已经持有 KWR 的进程

---

## 0. 先说清楚可行边界

「**透视绘制**」= 在游戏画面上画框。这需要**在游戏进程里执行代码**（注入 dylib 或 hook Metal 的渲染回调）。你现在有内核读写，没有代码执行，而且 18.3.2 的 A15 上：

| 门 | 状态 |
|---|---|
| AMFI 代码签名 | 拦注入 |
| PPL（保护页表） | 拦「把代码页改成可写」，A15 是 PPL，A16+ 是更狠的 SPTM |
| 18.3.2 公开 PPL bypass | **没有** |

所以**原地画 ESP 这一条，你今天做不成**。PiP 叠加窗口也不行：那是独立的系统小窗，坐标对不上游戏画面，画上去等于没画。

能成的两条：

1. **数据向自瞄**（静默准心）—— 只读写游戏内存里的角度、目标、后坐力。纯数据，不需要注入 ✅
2. **雷达** —— 读敌人世界坐标，在**我们自己的 App 里**画雷达/列表。不能叠在游戏上，但能开着看 ✅

这个仓库把这两条都写到位了，ESP 的**数学**（世界→屏幕投影）也写了，等哪天有代码执行，接上渲染就行。

---

## 1. 目录

```
src/kwr.h/.c        内核/用户态读写接口，后端可插拔
src/macho.h/.c      内存里解析 Mach-O：段表、节、导出表（找 il2cpp_* 符号）
src/il2cpp.h/.c     Unity 类发现：元数据头 → 类型定义表 → 运行时 Il2CppClass* → 实例
src/math3d.h        向量/矩阵、世界→屏幕投影、欧拉角、角度平滑
src/aim.h/.c        目标选取、FOV、部位、自瞄角度计算与写入
src/dump.h/.c       遍历 mapping、搜字符串、把任意内存 dump 成文件
src/cfm_offsets.h   **全是 TODO**：这些必须你自己从 dump 里对出来
src/host.c          命令行入口，宿主进程调 cfm_host_cmd()
```

**没有一个偏移是猜的也没有一个是抄的。** `il2cpp` 那一层故意做成运行时发现：元数据靠 magic `0xFAB11BAF` 扫，类名靠字符串表解，`Il2CppClass*` 靠「`name` 字段指向元数据字符串」反查，实例靠「对象第 0 个 qword 等于 klass」。这套在任何 Unity/IL2CPP 版本上都成立，不需要版本表。

---

## 2. 为什么必须自己 dump

CFM 是 Unity + IL2CPP + 腾讯 TP。**每版本类名可能被混淆、字段偏移必变**。你从任何地方拿来的偏移，都是别人机型别人的 build，套上去不会「不生效」，会**直接把进程读崩**。

正确顺序（这也是行业里真做法）：

1. **解密 App**：lara → 工具页 → **App Decrypt** → 拿到可分析的 CFM ipa
2. 用 IDA / Ghidra 打开 `UnityFramework` 和 `global-metadata.dat`，找：玩家的角度字段、相机 `main`、实体列表、敌人 `Transform`
3. 运行时用本仓库的 `dump` / `strings` / `class` 命令**验证**这些偏移在内存里确实对得上
4. 填进 `cfm_offsets.h`
5. 才能开自瞄

---

## 3. 用法（在持 KWR 的宿主里）

宿主需要提供两样东西：

```c
// 你的后端：把 ds1832 的原语包成 kwr_backend
static kwr_backend be = {
    .name = "ds1832",
    .kread = ..., .kwrite = ...,
    .uva_read = ..., .uva_write = ...,
    .region_next = ...,
};
kwr_register(&be);

// 宿主声明这个
int cfm_backend_attach(void) { return kwr_active() ? 0 : -1; }
```

然后：

```
cfm_host_cmd("regions 1234");                 // 游戏的 mapping 长什么样
cfm_host_cmd("exports 1234");                 // 找到 UnityFramework，解出 il2cpp_* 导出地址
cfm_host_cmd("meta 1234");                    // 定位 global-metadata，看版本号
cfm_host_cmd("find 1234 Player");              // 类名模糊搜（混淆了就搜 Controller/Entity/Hero）
cfm_host_cmd("class 1234 PlayerController");   // 拿到 Il2CppClass*，数一下有几个实例
cfm_host_cmd("strings 1234 Assembly-CSharp");  // 内存里搜字符串
cfm_host_cmd("dump 1234 0x102a00000 0x400000 /tmp/cfm_meta.bin");
```

**建号 → 进一局训练场 → 边跑边 dump**，比静态分析快得多。

---

## 4. 反作弊这块的实话

腾讯 TP 在 iOS 上主要看三类：越狱痕迹、注入的动态库、自身代码页被改。

本方案：

- ✅ 不注入、不 hook，进程里干净
- ✅ 只在外部读写内存
- ⚠️ **行为层仍会抓**：命中率异常、穿烟、秒转视角、K/D 突变，这些是服务端模型，不吃你技术
- ⚠️ 自瞄写角度如果写太硬（每帧直接把准心钉在头上），回放/服务端校验很容易看出来

操作上的建议就一句：**平滑给足、FOV 给小、别穿烟别秒转**。`CFM_AIM_SMOOTH` 默认 0.35 是能玩的下限，往下调就是找封。

---

## 5. 现状 / 下一步

| 层 | 状态 |
|---|---|
| 内核读写（宿主的 KWR 后端） | **未接**：ds1832 Part 1 只到物理越界读写，到任意内核虚拟读写还差 inpcb 那一步 |
| Mach-O 内存解析 | 完成 |
| il2cpp 类发现 / 实例枚举 | 完成 |
| 投影与自瞄数学 | 完成 |
| dump / strings / regions 工具 | 完成 |
| 偏移表 | **空**，等你的 dump |
| ESP 渲染 | 受限于无代码执行，只能做雷达（自有 App 内绘制） |

所以顺序是：**先补 ds1832 的 inpcb→内核虚拟读写（Part 2）→ 接上 `cfm_backend_attach` → 跑 `meta`/`find` → 抓偏移 → 开自瞄**。

---

## 6. 构建

```sh
# 在 Theos 环境里（或直接塞进 ds1832 的 Xcode 工程）
clang -c -arch arm64 -mios-version-min=15.0 -Isrc src/*.c
ar rcs libcfm.a *.o
```

`host.c` 里的 `cfm_host_cmd()` 可以直接挂到 ds1832 那个界面的一个文本框里，一行一条命令，省得来回改代码重签。
