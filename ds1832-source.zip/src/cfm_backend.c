// cfm_backend.c — the bridge between the cheat layer and our kernel primitives
//
// right now this returns -1 on purpose: ds1832 has the VFS race primitive (phys
// out-of-bounds read/write), but not yet the arbitrary kernel virtual read/write
// needed to walk another process's memory. when that lands (inpcb -> kobject ->
// kread/kwrite), fill in the two functions below and nothing else has to change.
//
// the interface the cheat layer expects is exactly kwr_backend: kread, kwrite,
// uva_read, uva_write, region_next. see cfm-cheat/src/kwr.h.
#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>

#include "kwr.h"

static int be_kread(uint64_t kva, void *buf, size_t len) { (void)kva; (void)buf; (void)len; return -1; }
static int be_kwrite(uint64_t kva, const void *buf, size_t len) { (void)kva; (void)buf; (void)len; return -1; }
static int be_uread(pid_t pid, uint64_t uva, void *buf, size_t len) { (void)pid; (void)uva; (void)buf; (void)len; return -1; }
static int be_uwrite(pid_t pid, uint64_t uva, const void *buf, size_t len) { (void)pid; (void)uva; (void)buf; (void)len; return -1; }
static int be_region(pid_t pid, uint64_t *cursor, uint64_t *start, uint64_t *size, uint32_t *prot) {
    (void)pid; (void)cursor; (void)start; (void)size; (void)prot;
    return 1;   // end of list: no mappings known until kread exists
}

static const kwr_backend g_backend = {
    .name = "ds1832-pending",
    .kread = be_kread,
    .kwrite = be_kwrite,
    .uva_read = be_uread,
    .uva_write = be_uwrite,
    .region_next = be_region,
};

// called by cfm_host_cmd() before every command
int cfm_backend_attach(void) {
    if (!kwr_active())
        kwr_register(&g_backend);
    // flip this to 0 once the kernel virtual read/write path is implemented
    return -1;
}
