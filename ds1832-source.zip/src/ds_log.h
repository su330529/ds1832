// ds_log.h — file-backed logging for panic-prone runs
// one implementation (ds_log.c) so every translation unit appends to the same
// file; a panic wipes the process, so each line is flushed before the next syscall.
#ifndef DS_LOG_H
#define DS_LOG_H

void ds_log_open(const char *dir);
void ds_log(const char *fmt, ...);

#define DS_LOG(...) ds_log(__VA_ARGS__)

#endif
