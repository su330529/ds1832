// ds_log.c — see ds_log.h
#include "ds_log.h"

#include <stdio.h>
#include <stdarg.h>
#include <sys/time.h>
#include <unistd.h>

static FILE *ds_fp = NULL;
static char ds_path[512];

void ds_log_open(const char *dir) {
    snprintf(ds_path, sizeof(ds_path), "%s/ds-run.log", dir);
    ds_fp = fopen(ds_path, "a");
    if (ds_fp)
        setvbuf(ds_fp, NULL, _IONBF, 0);   // unbuffered: the last line survives a panic
}

void ds_log(const char *fmt, ...) {
    struct timeval tv;
    gettimeofday(&tv, NULL);

    char line[2048];
    int n = snprintf(line, sizeof(line), "[%lld.%03d] ",
                     (long long)tv.tv_sec, (int)(tv.tv_usec / 1000));
    va_list ap;
    va_start(ap, fmt);
    n += vsnprintf(line + n, sizeof(line) - (size_t)n, fmt, ap);
    va_end(ap);
    if (n < 0)
        return;
    if (n > (int)sizeof(line) - 2)
        n = (int)sizeof(line) - 2;
    line[n++] = '\n';

    fwrite(line, 1, (size_t)n, stderr);
    if (ds_fp) {
        fwrite(line, 1, (size_t)n, ds_fp);
        fsync(fileno(ds_fp));
    }
}
