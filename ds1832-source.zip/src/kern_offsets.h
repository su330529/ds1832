// kern_offsets.h — 真机抓下来的内核偏移（不是猜的，不是抄的）
//
// 来源：iPhone14,3 / iOS 18.3.2 / xnu-11215.82.4~20 / RELEASE_ARM64_T8110
// 由 lara v0.2 的 XPF 在你自己的机器上解析并打印（(offs) 与 (ds) 两组日志）
//
// 校验基准：
//   static base  = 0xfffffff007004000
//   runtime base = 0xfffffff04c30c000   -> slide 0x45308000
//   静态偏移 + slide 必须等于运行时地址，否则这套表就不能用
#ifndef KERN_OFFSETS_H
#define KERN_OFFSETS_H

// ---- 页表与地址翻译 -------------------------------------------------------
// T1SZ_BOOT = 0x19  ->  顶部两级页表覆盖 25 位，VA 宽度 64-25 = 39 位
#define KOFF_T1SZ_BOOT               0x19
#define KOFF_VIRT_BASE_PLACEHOLDER   0ULL    // 运行时取 kernel_base
#define KOFF_PHYS_BASE_PLACEHOLDER   0ULL

// ---- 内核 Mach-O / 基址 --------------------------------------------------
// kernentry 是带 slide 之前的静态地址
#define KOFF_STATIC_KERNBASE         0xfffffff007004000ULL
#define KOFF_STATIC_KERNENTRY        0xfffffff00a254000ULL

// ---- 数据符号（相对 kernel_base 的偏移）-----------------------------------
// 日志：(offs) allproc: 0x3527b40 / kernproc: 0x9fddf8 / rootvnode: 0x3528160
#define KOFF_ALLPROC                 0x03527b40ULL
#define KOFF_KERNPROC                0x009fddf8ULL
#define KOFF_ROOTVNODE               0x03528160ULL

// ---- 结构尺寸 ------------------------------------------------------------
#define KSIZE_PROC                   0x740ULL

// ---- 结构字段 ------------------------------------------------------------
#define KOFF_PROC_PID                0x28      // (utils) PROC_PID_OFFSET
#define KOFF_TASK_TNEXT              0x50      // (utils) TASK_TNEXT_OFFSET
#define KOFF_THREAD_MUPCB            0xb8      // (utils) THREAD_MUPCB_OFFSET
#define KOFF_SOCKET_SO_COUNT         0x254     // (ds) iOS 18: using so_count offset 0x254

// ---- proc_ro / ucred（来自 (sbx) 段的实测）--------------------------------
// (sbx) found ucred at proc_ro+0x20
#define KOFF_PROC_RO_UCRED           0x20

// ---- inpcb.icmp6filt -----------------------------------------------------
// 由 (ds) 日志两次地址差推出：inp 0xffffffe0a69bc400 -> corrupted target
// 0xffffffe0a69bc548，差 0x148。**这是推导值，上机要复核。**
#define KOFF_INPCB_ICMP6FILT         0x148

// ---- 运行时填充（由 exploit 写入，不要硬编码）-----------------------------
typedef struct {
    uint64_t kernel_base;      // 0xfffffff04c30c000 这一版
    uint64_t kernel_slide;     // 0x45308000
    uint64_t allproc;          // kernel_base + KOFF_ALLPROC
    uint64_t kernproc;
    uint64_t rootvnode;
    uint64_t our_proc;         // 0xffffffdfbb1e4980 这一版
    uint64_t our_task;         // 0xffffffdfbb1e50c0 这一版
    uint64_t control_socket;   // fd -> socket 指针，darksword 找到的那个
    uint64_t rw_socket;
    uint64_t so_count;         // 偏移，不是地址
    uint64_t procsize;
} kern_runtime;

#endif
