// iosurface_compat.h — IOSurface is a private framework; the community iOS SDKs
// ship its .tbd but not its headers. declare the three entry points we use so the
// same source builds both in Xcode (where the header exists) and with a bare SDK.
#ifndef IOSURFACE_COMPAT_H
#define IOSURFACE_COMPAT_H

#include <CoreFoundation/CoreFoundation.h>
#include <stddef.h>

typedef struct __IOSurface *IOSurfaceRef;

extern IOSurfaceRef IOSurfaceCreate(CFDictionaryRef properties);
extern void        *IOSurfaceGetBaseAddress(IOSurfaceRef buffer);
extern size_t       IOSurfaceGetBytesPerRow(IOSurfaceRef buffer);
extern size_t       IOSurfaceGetAllocSize(IOSurfaceRef buffer);
extern void         IOSurfacePrefetchPages(IOSurfaceRef buffer);
extern void         IOSurfaceLock(IOSurfaceRef buffer, uint32_t options, uint32_t *seed);
extern void         IOSurfaceUnlock(IOSurfaceRef buffer, uint32_t options, uint32_t *seed);

#endif
