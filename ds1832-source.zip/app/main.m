// main.m — one app, three things: the primitive chain, the cheat console, the overlay test
#import <UIKit/UIKit.h>
#include <objc/message.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include "ds_exploit.h"
#include "ds_log.h"

// from cfm-cheat/src
int cfm_host_cmd(const char *line);

// overlay / input probes (Objective-C, from cfm-cheat/src)
@interface DSOverlay : NSObject
- (BOOL)start;
- (void)stop;
@end
@interface DSInput : NSObject
+ (BOOL)start;
+ (BOOL)available;
@end

static ds_result g_res;
static volatile int g_done = 1;
static char g_out_path[512];

static void *ds_thread(void *arg) {
    (void)arg;
    ds_exploit_run(&g_res);
    g_done = 1;
    return NULL;
}

@interface DSViewController : UIViewController <UITextFieldDelegate>
@property (nonatomic, strong) UITextView *log;
@property (nonatomic, strong) UITextField *cmd;
@property (nonatomic, strong) UILabel *status;
@property (nonatomic, strong) NSTimer *poll;
@property (nonatomic, strong) id overlay;
@end

@implementation DSViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    CGRect b = self.view.bounds;

    self.status = [[UILabel alloc] initWithFrame:CGRectMake(12, 52, b.size.width - 24, 54)];
    self.status.textColor = [UIColor colorWithRed:0.4 green:1.0 blue:0.5 alpha:1.0];
    self.status.numberOfLines = 0;
    self.status.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    self.status.text = @"idle";
    [self.view addSubview:self.status];

    UIButton *run = [UIButton buttonWithType:UIButtonTypeSystem];
    run.frame = CGRectMake(12, 112, 150, 40);
    [run setTitle:@"run primitive" forState:UIControlStateNormal];
    run.titleLabel.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightBold];
    [run addTarget:self action:@selector(runTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:run];

    UIButton *ov = [UIButton buttonWithType:UIButtonTypeSystem];
    ov.frame = CGRectMake(180, 112, 90, 40);
    [ov setTitle:@"overlay" forState:UIControlStateNormal];
    ov.titleLabel.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightBold];
    [ov addTarget:self action:@selector(overlayTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:ov];

    UIButton *inp = [UIButton buttonWithType:UIButtonTypeSystem];
    inp.frame = CGRectMake(278, 112, 90, 40);
    [inp setTitle:@"input" forState:UIControlStateNormal];
    inp.titleLabel.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightBold];
    [inp addTarget:self action:@selector(inputTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:inp];

    self.cmd = [[UITextField alloc] initWithFrame:CGRectMake(12, 158, b.size.width - 24, 34)];
    self.cmd.backgroundColor = [UIColor colorWithWhite:0.15 alpha:1.0];
    self.cmd.textColor = [UIColor whiteColor];
    self.cmd.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
    self.cmd.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.cmd.autocorrectionType = UITextAutocorrectionTypeNo;
    self.cmd.returnKeyType = UIReturnKeyGo;
    self.cmd.delegate = self;
    self.cmd.placeholder = @"cfm_host: regions <pid> | exports <pid> | meta <pid> | find <pid> <str> | class <pid> <ns> <name> | strings <pid> <str> | dump <pid> <va> <len> <path>";
    [self.view addSubview:self.cmd];

    self.log = [[UITextView alloc] initWithFrame:CGRectMake(8, 198, b.size.width - 16, b.size.height - 216)];
    self.log.backgroundColor = [UIColor colorWithWhite:0.07 alpha:1.0];
    self.log.textColor = [UIColor colorWithWhite:0.85 alpha:1.0];
    self.log.font = [UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightRegular];
    self.log.editable = NO;
    [self.view addSubview:self.log];

    NSString *dir = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    ds_log_open([dir UTF8String]);
    snprintf(g_out_path, sizeof(g_out_path), "%s/stdout.log", [dir UTF8String]);

    // the cheat layer prints with printf; give it a real sink the UI can tail
    freopen(g_out_path, "a", stdout);
    setvbuf(stdout, NULL, _IONBF, 0);

    self.poll = [NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(refresh) userInfo:nil repeats:YES];
}

- (void)runTapped {
    self.status.text = @"racing (may panic the kernel)";
    g_done = 0;
    memset(&g_res, 0, sizeof(g_res));
    pthread_t t;
    pthread_attr_t a;
    pthread_attr_init(&a);
    pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
    pthread_create(&t, &a, ds_thread, NULL);
    pthread_attr_destroy(&a);
}

- (void)overlayTapped {
    Class c = NSClassFromString(@"DSOverlay");
    if (!c) { printf("overlay: DSOverlay not linked\n"); return; }
    self.overlay = ((id (*)(id, SEL))objc_msgSend)([c alloc], NSSelectorFromString(@"init"));
    BOOL ok = ((BOOL (*)(id, SEL))objc_msgSend)(self.overlay, NSSelectorFromString(@"start"));
    printf("overlay: %s\n", ok ? "started" : "FAILED (entitlement com.apple.QuartzCore.displayable-context)");
}

- (void)inputTapped {
    Class c = NSClassFromString(@"DSInput");
    if (!c) { printf("input: DSInput not linked\n"); return; }
    BOOL ok = ((BOOL (*)(id, SEL))objc_msgSend)(c, NSSelectorFromString(@"start"));
    printf("input: %s (hid=%d)\n", ok ? "ready" : "FAILED",
           ((BOOL (*)(id, SEL))objc_msgSend)(c, NSSelectorFromString(@"available")));
}

- (BOOL)textFieldShouldReturn:(UITextField *)tf {
    [tf resignFirstResponder];
    printf("\n> %s\n", [tf.text UTF8String]);
    cfm_host_cmd([tf.text UTF8String]);
    tf.text = @"";
    return YES;
}

- (void)refresh {
    NSString *all = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:g_out_path]
                                              encoding:NSUTF8StringEncoding error:nil];
    if (all.length) {
        self.log.text = all;
        [self.log scrollRangeToVisible:NSMakeRange(all.length - 1, 1)];
    }
    if (g_done) return;
    NSString *stage = @"?";
    switch (g_res.stage) {
        case DS_STAGE_INIT: stage = @"init"; break;
        case DS_STAGE_CALIBRATE: stage = @"calibrate"; break;
        case DS_STAGE_ARENA: stage = @"arena"; break;
        case DS_STAGE_SPRAY: stage = @"spray"; break;
        case DS_STAGE_RACE: stage = @"racing"; break;
        case DS_STAGE_FOUND_SELF: stage = @"ADJACENCY"; break;
        case DS_STAGE_FOUND_SOCKET: stage = @"INPCB"; break;
        case DS_STAGE_FAILED: stage = @"failed"; break;
        default: stage = @"idle"; break;
    }
    self.status.text = [NSString stringWithFormat:@"%@  attempts %llu  contig %llu  socks %d",
                        stage, (unsigned long long)g_res.attempts,
                        (unsigned long long)g_res.contig_hits, g_res.sockets_live];
}

@end

@interface DSAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation DSAppDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)opts {
    (void)app; (void)opts;
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[DSViewController alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DSAppDelegate class]));
    }
}
